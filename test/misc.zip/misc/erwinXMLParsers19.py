#!/usr/bin/python

# from toposort import toposort
import xml.etree.ElementTree as ET
import json

from xml.dom.minidom import parse
import xml.dom.minidom

tree = ET.parse('H:\DataModeler\dmc\data\input\NorthwindXmlMinFile.xml')
root = tree.getroot()
adjMap = {}

def makeEntities():
    # Open XML document using minidom parser
    DOMTree = xml.dom.minidom.parse("H:\DataModeler\dmc\data\input\NorthwindXmlMinFile.xml")
    root = DOMTree.documentElement

    entityGroups = root.getElementsByTagName("Entity_Groups")

    for etGroup in entityGroups:
        entity = etGroup.getElementsByTagName("Entity")
        for et in entity:
            if et.getElementsByTagName("EntityProps"):
                entityProps = et.getElementsByTagName("EntityProps")
                for eptags in entityProps:
                    schema = eptags.getElementsByTagName("Schema_Name")[0]
                    schema_name = schema.childNodes[0].data
                    print schema_name

                    table = eptags.getElementsByTagName("Name")[0]
                    table_name = table.childNodes[0].data
                    print table_name

            if et.getElementsByTagName("Attribute_Groups"):
                attributeGroups = et.getElementsByTagName("Attribute_Groups")
                for agtags in attributeGroups:
                    attributeProps = et.getElementsByTagName("AttributeProps")
                    ordinal_position = 0
                    for aptags in attributeProps:
                        if aptags.getElementsByTagName("Name"):
                            column = aptags.getElementsByTagName("Name")[0]
                            column_name = column.childNodes[0].data
                            ordinal_position += 1

                        if aptags.getElementsByTagName("Physical_Data_Type"):
                            column = aptags.getElementsByTagName("Physical_Data_Type")[0]
                            column_data_type = column.childNodes[0].data
                        else:
                            column_data_type = 'varchar(108)'

                        print column_name + '^' + column_data_type + '^' + str(ordinal_position)

            if et.getElementsByTagName("Key_Group_Groups"):
                for kggtags in et.getElementsByTagName("Key_Group_Groups"):
                    if kggtags.getElementsByTagName("Key_Group"):
                        constraint_type = ''
                        for kgtags in kggtags.getElementsByTagName("Key_Group"):
                            for kgptags in kgtags.getElementsByTagName("Key_GroupProps"):
                                if kgptags.getElementsByTagName("Key_Group_Type"):
                                    key = kgptags.getElementsByTagName("Key_Group_Type")[0]
                                    key_type = key.childNodes[0].data
                                    # print "key_type:" + str(key_type)

                                if str(key_type).upper() == 'PK':
                                    if kgtags.hasAttribute("name"):
                                        constraint_type = kgtags.getAttribute("name")

                                    for kgmgtags in kgtags.getElementsByTagName("Key_Group_Member_Groups"):
                                        if kgmgtags.getElementsByTagName("Key_Group_Member"):
                                            constraint_column = ''
                                            for kgmtags in kgmgtags.getElementsByTagName("Key_Group_Member"):
                                                if kgmtags.hasAttribute("name"):
                                                    constraint_column = kgmtags.getAttribute("name")
                                                    print "constraint_column:" + str(constraint_column) + " constraint_type:" + str(constraint_type) + " key_type:" + str(key_type)


                                if str(key_type)[0:2].upper() == 'IF':
                                    constraint_type = "FOREGIN"
                                    print "constraint_type:" + str(constraint_type)

                                    if kgptags.getElementsByTagName("Name"):
                                        constraint = kgptags.getElementsByTagName("Name")[0]
                                        constraint_name = constraint.childNodes[0].data
                                        print "constraint_name:" + str(constraint_name)

                                    for kgmgtags in kgtags.getElementsByTagName("Key_Group_Member_Groups"):
                                        if kgmgtags.getElementsByTagName("Key_Group_Member"):
                                            constraint_column = ''
                                            for kgmtags in kgmgtags.getElementsByTagName("Key_Group_Member"):
                                                if kgmtags.hasAttribute("name"):
                                                    constraint_column = kgmtags.getAttribute("name")
                                                    print "constraint_column:" + str(constraint_column)

                                            for kgmptags in kgmgtags.getElementsByTagName("Key_Group_MemberProps"):
                                                if kgmptags.getElementsByTagName("Parent_Key_Group_Member_Ref"):
                                                    parent_key_ref = kgmptags.getElementsByTagName("Parent_Key_Group_Member_Ref")[0]
                                                    parent_key_ref_name = parent_key_ref.childNodes[0].data
                                                    print "parent_key_ref_name:" + str(parent_key_ref_name)




def makeEntities1():
    for child in root:
        print child.tag
        print child.attrib
        if "Model" in child.tag:
            childName = child.attrib["name"]
            print childName
            dependencies = set()
            for subChild in child:
                print subChild
                subChildTag = subChild.tag
                print subChildTag
                if "Entity_Groups" in subChildTag:
                    for entityGroupsChild in subChild:
                        if "Entity" in entityGroupsChild.tag:
                            print "entityGroupsChild: " + str(entityGroupsChild)
                            for entityChild in entityGroupsChild:
                                print "entityChild v: " + str(entityChild)
                                if "EntityProps" in entityChild.tag:
                                    entityPropsTag = entityChild.tag
                                    print "EntityProps: " + str(entityChild)
                                    print "entityPropsTag:" + str(entityPropsTag)
                                    # for elem in entityChild.tag.iter(tag='EntityProps'):
                                    #     print elem

                                    # for entityProps in entityPropsTag:
                                    #     print entityProps

                                if "Attribute_Groups" in entityChild.tag:
                                    print "Attribute_Groups: " + str(entityChild)
                                if "Key_Group_Groups" in entityChild.tag:
                                    print "Key_Group_Groups: " + str(entityChild)


                            # dependencies.add(keyRefChild.attrib["xpath"][3:])

            adjMap[childName] = dependencies

def dfs(graph):
    jsonGraph = {}
    jsonGraph["name"] = "root";
    jsonGraph["children"] = []
    visited = set()
    for vertex in adjMap:
        if vertex not in visited:
            jsonGraph["children"].append(explore(vertex, visited))
    return json.dumps(jsonGraph)

def explore(parentName, visited):
    parentDict = {}
    parentDict["name"] = parentName
    visited.add(parentName)
    leaf = True
    if parentName in adjMap:
        for child in adjMap[parentName]:
            if child not in visited:
                leaf = False
                if "children" not in parentDict:
                    parentDict["children"] = []
                parentDict["children"].append(explore(child,visited))
    if leaf:
        parentDict["size"] = 1994
    return parentDict

# def topologicalSort(graph):
#     topoList = list(toposort(graph))
#     dfs(topoList)

def main():
    makeEntities()
    #topologicalSort(adjMap)
    jsonGraph = dfs(adjMap)
    print jsonGraph
    with open("edw.json","w") as f:
        f.write(jsonGraph)

if __name__ == "__main__":
    main()



    # if kgptags.getElementsByTagName("Name"):
    #     constraint = kgptags.getElementsByTagName("Name")[0]
    #     constraint_key = constraint.childNodes[0].data
    #     print "constraint_key:" + str(constraint_key)