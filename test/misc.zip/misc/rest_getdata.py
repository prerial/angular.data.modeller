#!/usr/bin/python

import urllib
import requests
import json

import httplib, subprocess

"""
 * @author n662293
 """

import utilities
def main():
    # erwin_xmlfile = "H:\DataModeler\dmc\data\input\NorthwindXmlMinFile.xml"
    # exclude_tables = None
    # include_tables = None
    # url = "http://localhost:5000/todo/api/v1.0/tasks"
    # datasource_url = "http://localhost:5000/dmc/v1.0/schemas"
    # purl = 'http://localhost:5000/todo/api/v1.0/taskspost'
    get_db_connection()
    post_erd_json()

"""
 * Function to parse erwin xml file
 """
def get_db_connection():
    print utilities.Config.DB_CONN_URL
    response = urllib.urlopen(utilities.Config.DB_CONN_URL)
    data = json.loads(response.read())
    print "get method output"
    print json.dumps(data,indent=2)

def post_erd_json():
    data = {'sender': 'Alice', 'receiver': 'Bob', 'message': 'We did it!'}
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    response = requests.post(utilities.Config.DB_ERD_URL, data=json.dumps(data), headers=headers)
    print "post method output response code:" + str(response.status_code)
    pastebin_url = response.text
    print("The pastebin URL is:%s" % pastebin_url)


if __name__ == "__main__":
    main()