#!/usr/bin/python

import utilities

"""
 * @author n662293
 """

# def main():

   # key = "employees"
   # for dict in entity_json:
   #  # print key
   #  # print dict
   #  entity_flag = 0
   #  for k, v in dict.iteritems():
   #   # print k
   #   if dict.has_key(k):
   #    if str(k).lower() == "entity_name":
   #     entity_name = dict.get(k)
   #     if entity_name == key:
   #      entity_flag = 1
   #      print "entity_name:" + entity_name
   #
   #    if entity_flag == 1:
   #     if str(k).lower() == "fields":
   #      fields = dict.get(k)
   #      print "fieldsvvvvvvvvvvvv:" + str(fields)

        # erd_json = generate_erdjson(entity_json)
        # print erd_json


"""
 * Function to generate denormalized native ddls
 """
def generate_erdjson(entity_json):
    utilities.print_info("Generating ERD json process started...")

    tree_file = utilities.Config.NORTHWIND_CSV_FILE
    treefile = open(tree_file, 'r')
    tree_list = []
    for line in treefile:
        tree_list.append(line)

    erd_dict = []
    erd_dict.append("[")
    erd_dict.append("{")
    root_flag = 1
    prev_level = ''
    prev_parent_level = ''
    bracket_count = 0
    flower_count = 0
    root_count = 0

    for row in tree_list:
        row_split = str(row.rstrip("\n")).lower().split(":")
        parent_level = row_split[0]
        current_level = row_split[1]
        key = row_split[2]

        for dict in entity_json:
            entity_flag = 0
            for k, v in dict.iteritems():
                if dict.has_key(k):
                    if str(k).lower() == "table":
                        entity_name = dict.get(k)
                        if entity_name == key:
                            entity_flag = 1
                            print "entity:" + entity_name + " entity_flag:" + str(entity_flag)

                    if entity_flag == 1:
                        print "str(k).lower():" + str(k).lower()
                        if str(k).lower() == "fields":
                            fields = dict.get(k)
                            print "fields:" + str(fields)
                            print "entity flag parent_level:" + parent_level + " current_level:" + current_level + " key:" + key

                            if prev_level in parent_level:

                                print "if prev_level:" + prev_level + " parent_level:" + parent_level + " current_level:" + current_level + " key:" + key

                                if root_flag == 1:
                                    print 'if root:' + str(key)
                                    erd_dict.append('"name":' + '"' + str(key) + '",')
                                    erd_dict.append('"columns":' + str(fields))
                                    root_flag = 0
                                else:
                                    print 'else root:' + str(key)
                                    erd_dict.append(',"children":[')
                                    erd_dict.append('{')
                                    print "["
                                    print "{"
                                    erd_dict.append('"name":' + '"' + str(key) + '",')
                                    erd_dict.append('"columns":' + str(fields))
                                    flower_count += 1
                                    bracket_count += 1
                                    print 'else root:' + str(key) + " flower_count:" + str(flower_count) + " bracket_count:" + str(bracket_count)

                            elif prev_parent_level in parent_level:
                                print "elif prev_parent_level:" + prev_parent_level + " parent_level:" + parent_level + " current_level:" + current_level + " key:" + key
                                root_flag = 1
                                if root_flag == 1:
                                    print 'elif if root:' + str(key) + " flower_count:" + str(flower_count) + " bracket_count:" + str(bracket_count)
                                    flower_count = flower_count - 1
                                    erd_dict.append('}')
                                    erd_dict.append(',{')
                                    print "}"
                                    print ",{"
                                    erd_dict.append('"name":' + '"' + str(key) + '",')
                                    erd_dict.append('"columns":' + str(fields))
                                    root_flag = 0
                                    root_count += 1

                            else:
                                print "else prev_level:" + prev_level + " parent_level:" + parent_level + " prev_parent_level:" + prev_parent_level + " parent_level:" + parent_level + " current_level:" + current_level + " key:" + key\
                                      + " flower_count:" + str(flower_count) + " bracket_count:" + str(bracket_count) + " root_count:" + str(root_count)

                                root_flag = 1
                                if root_flag == 1:
                                    for i in range(flower_count-1):
                                        erd_dict.append('}')
                                        erd_dict.append(']')
                                        print "}"
                                        print "]"

                                    erd_dict.append('}')
                                    print "}"
                                    flower_count = 0
                                    bracket_count =  bracket_count - i - 1
                                    print "else bracket_count: " + str(bracket_count) + " - :" + str(i)
                                    child_count = 0
                                    erd_dict.append(',{')
                                    print ",{"
                                    erd_dict.append('"name":' + '"' + str(key) + '",')
                                    erd_dict.append('"columns":' + str(fields))
                                    root_count += 1
                                    flower_count += 1
                                    root_flag = 0
                                    print 'else root:' + str(key)

        prev_level = current_level
        prev_parent_level = parent_level

    print str(key) + " flower_count:" + str(flower_count) + " bracket_count:" + str(bracket_count) + " root_count:" + str(root_count)

    erd_dict.append('}')
    print "}"
    for i in range(bracket_count):
        erd_dict.append(']')
        erd_dict.append('}')
        print "]"
        print "}"

    erd_dict.append(']')
    print "]"

    erd_json = "\n".join(erd_dict)

    utilities.print_info("Generating ERD json process completed...")

    return erd_json
#
# if __name__ == '__main__':
#     main()

