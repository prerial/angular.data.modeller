from datetime import datetime
from flask import Flask, jsonify, abort


import logging
import sys
import os
import ConfigParser

def get_schemas():
    return jsonify({'databases': schemas})

def get_schema(schema_id):
    sh = [sh for sh in schemas if sh['id'] == schema_id]
    if len(sh) == 0:
        abort(404)
    return jsonify({'task': sh[0]})


def get_databases():
    return jsonify({'databases': databases})

def get_db(db_id):
    db = [db for db in databases if db['id'] == db_id]
    if len(db) == 0:
        abort(404)
    return jsonify({'task': db[0]})

databases = [
    {
        'id': 1,
        'name': u'DB2',
        'version': u'5.x/6.x/7.x',
        'support': False
    },
    {
        'id': 2,
        'name': u'Informix',
        'version': u'10.x/11.x/12.x',
        'support': False
    },
    {
        'id': 3,
        'name': u'MySQL',
        'version': u'5.x',
        'support': True
    },
    {
        'id': 4,
        'name': u'Oracle',
        'version': u'11g/12c',
        'support': True
    },
    {
        'id': 5,
        'name': u'Progress',
        'version': u'9.x/10.x',
        'support': False
    },
    {
        'id': 6,
        'name': u'SQL Server',
        'version': u'2012/2014',
        'support': False
    },
    {
        'id': 7,
        'name': u'Sybase',
        'version': u'15.x/16',
        'support': False
    },
    {
        'id': 8,
        'name': u'Teradata',
        'version': u'13.x/14.x/15.x',
        'support': False
    }
]


schemas = [
    {
        'id': 1,
        'name': u'northwind',
        'db_id': 3
    },
    {
        'id': 2,
        'name': u'daf',
        'db_id': 3
    }

]

