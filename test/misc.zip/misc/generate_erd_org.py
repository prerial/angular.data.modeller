#!/usr/bin/python

import dmc.core.utilities
import json
from collections import OrderedDict
from distutils.core import setup


import re
from dmc.core.hive_ddl_parser import generate_hive_ddl

"""
 * @author n662293
 """

"""
 * Function to generate denormalized ddls
 """

def main():

    json_list = [
 {
  "namespace": "northwind.categories",
  "type": "record",
  "entity_name": "categories",
  "fields": [
   {
    "column_type": "int",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "categoryid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "11"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "categoryname",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "mediumtext",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "description",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   },
   {
    "column_type": "longblob",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "picture",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   }
  ]
 },
 {
  "namespace": "northwind.customercustomerdemo",
  "type": "record",
  "entity_name": "customercustomerdemo",
  "fields": [
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "customerid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "5"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "customerid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "customerid",
    "referenced_table_name": "customers",
    "primaryKey": "false",
    "size": "5"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "customertypeid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "10"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "customertypeid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "customertypeid",
    "referenced_table_name": "customerdemographics",
    "primaryKey": "false",
    "size": "10"
   }
  ]
 },
 {
  "namespace": "northwind.customerdemographics",
  "type": "record",
  "entity_name": "customerdemographics",
  "fields": [
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "customertypeid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "10"
   },
   {
    "column_type": "mediumtext",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "customerdesc",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   }
  ]
 },
 {
  "namespace": "northwind.customers",
  "type": "record",
  "entity_name": "customers",
  "fields": [
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "customerid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "5"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "companyname",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "40"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "contactname",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "30"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "contacttitle",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "30"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "address",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "60"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "city",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "region",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "postalcode",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "10"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "country",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "phone",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "24"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "fax",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "24"
   }
  ]
 },
 {
  "namespace": "northwind.employees",
  "type": "record",
  "entity_name": "employees",
  "fields": [
   {
    "column_type": "int",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "employeeid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "11"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "lastname",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "20"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "firstname",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "10"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "title",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "30"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "titleofcourtesy",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "25"
   },
   {
    "column_type": "datetime",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "birthdate",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   },
   {
    "column_type": "datetime",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "hiredate",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "address",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "60"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "city",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "region",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "postalcode",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "10"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "country",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "homephone",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "24"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "extension",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "4"
   },
   {
    "column_type": "longblob",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "photo",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   },
   {
    "column_type": "mediumtext",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "notes",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   },
   {
    "column_type": "int",
    "referenced_column_name": "employeeid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "reportsto",
    "referenced_table_name": "employees",
    "primaryKey": "false",
    "size": "11"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "photopath",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "255"
   },
   {
    "column_type": "float",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "salary",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   }
  ]
 },
 {
  "namespace": "northwind.employeeterritories",
  "type": "record",
  "entity_name": "employeeterritories",
  "fields": [
   {
    "column_type": "int",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "employeeid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "11"
   },
   {
    "column_type": "int",
    "referenced_column_name": "employeeid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "employeeid",
    "referenced_table_name": "employees",
    "primaryKey": "false",
    "size": "11"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "territoryid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "20"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "territoryid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "territoryid",
    "referenced_table_name": "territories",
    "primaryKey": "false",
    "size": "20"
   }
  ]
 },
 {
  "namespace": "northwind.orderdetails",
  "type": "record",
  "entity_name": "orderdetails",
  "fields": [
   {
    "column_type": "int",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "orderid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "11"
   },
   {
    "column_type": "int",
    "referenced_column_name": "orderid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "orderid",
    "referenced_table_name": "orders",
    "primaryKey": "false",
    "size": "11"
   },
   {
    "column_type": "int",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "productid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "11"
   },
   {
    "column_type": "int",
    "referenced_column_name": "productid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "productid",
    "referenced_table_name": "products",
    "primaryKey": "false",
    "size": "11"
   },
   {
    "column_type": "decimal",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "unitprice",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "10,4"
   },
   {
    "column_type": "smallint",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "quantity",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "2"
   },
   {
    "column_type": "double",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "discount",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "8,0"
   }
  ]
 },
 {
  "namespace": "northwind.orders",
  "type": "record",
  "entity_name": "orders",
  "fields": [
   {
    "column_type": "int",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "orderid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "11"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "customerid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "customerid",
    "referenced_table_name": "customers",
    "primaryKey": "false",
    "size": "5"
   },
   {
    "column_type": "int",
    "referenced_column_name": "employeeid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "employeeid",
    "referenced_table_name": "employees",
    "primaryKey": "false",
    "size": "11"
   },
   {
    "column_type": "datetime",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "orderdate",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   },
   {
    "column_type": "datetime",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "requireddate",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   },
   {
    "column_type": "datetime",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "shippeddate",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   },
   {
    "column_type": "int",
    "referenced_column_name": "shipperid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "shipvia",
    "referenced_table_name": "shippers",
    "primaryKey": "false",
    "size": "11"
   },
   {
    "column_type": "decimal",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "freight",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "10,4"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "shipname",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "40"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "shipaddress",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "60"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "shipcity",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "shipregion",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "shippostalcode",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "10"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "shipcountry",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   }
  ]
 },
 {
  "namespace": "northwind.products",
  "type": "record",
  "entity_name": "products",
  "fields": [
   {
    "column_type": "int",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "productid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "11"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "productname",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "40"
   },
   {
    "column_type": "int",
    "referenced_column_name": "supplierid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "supplierid",
    "referenced_table_name": "suppliers",
    "primaryKey": "false",
    "size": "11"
   },
   {
    "column_type": "int",
    "referenced_column_name": "categoryid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "categoryid",
    "referenced_table_name": "categories",
    "primaryKey": "false",
    "size": "11"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "quantityperunit",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "20"
   },
   {
    "column_type": "decimal",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "unitprice",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "10,4"
   },
   {
    "column_type": "smallint",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "unitsinstock",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "2"
   },
   {
    "column_type": "smallint",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "unitsonorder",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "2"
   },
   {
    "column_type": "smallint",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "reorderlevel",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "2"
   },
   {
    "column_type": "bit",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "discontinued",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "1"
   }
  ]
 },
 {
  "namespace": "northwind.region",
  "type": "record",
  "entity_name": "region",
  "fields": [
   {
    "column_type": "int",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "regionid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "11"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "regiondescription",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "50"
   }
  ]
 },
 {
  "namespace": "northwind.shippers",
  "type": "record",
  "entity_name": "shippers",
  "fields": [
   {
    "column_type": "int",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "shipperid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "11"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "companyname",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "40"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "phone",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "24"
   }
  ]
 },
 {
  "namespace": "northwind.suppliers",
  "type": "record",
  "entity_name": "suppliers",
  "fields": [
   {
    "column_type": "int",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "supplierid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "11"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "companyname",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "40"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "contactname",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "30"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "contacttitle",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "30"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "address",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "60"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "city",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "region",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "postalcode",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "10"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "country",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "15"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "phone",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "24"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "fax",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "24"
   },
   {
    "column_type": "mediumtext",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "homepage",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": 0
   }
  ]
 },
 {
  "namespace": "northwind.territories",
  "type": "record",
  "entity_name": "territories",
  "fields": [
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "PRIMARY KEY",
    "column_name": "territoryid",
    "referenced_table_name": "null",
    "primaryKey": "true",
    "size": "20"
   },
   {
    "column_type": "varchar",
    "referenced_column_name": "null",
    "constraint_type": "null",
    "column_name": "territorydescription",
    "referenced_table_name": "null",
    "primaryKey": "false",
    "size": "50"
   },
   {
    "column_type": "int",
    "referenced_column_name": "regionid",
    "constraint_type": "FOREIGN KEY",
    "column_name": "regionid",
    "referenced_table_name": "region",
    "primaryKey": "false",
    "size": "11"
   }
  ]
 }
]

    json_file = "H:\DataModeler\dmc\data\output\json_file_new.json"
    tree_file = "H:\DataModeler\dmc\data\input\\northwind.csv"

    dict1 = {}
    for dict in json_list.__iter__():
        dict1 = dict.copy()

    key = "employee"
    for k, v in dict1.iteritems():
        if dict1.has_key(k):
            if str(k).lower() == "entity_name":
                fields = dict1.get(k)
                print fields
            if str(k).lower() == "fields":
                fields = dict1.get(k)
                print fields

    # print json.dumps(dict1,indent=2)
    generate_erd(tree_file,json_file,json_list)

"""
 * Function to generate denormalized native ddls
 """
def generate_erd(tree_file,json_file,json_list):
    dmc.core.utilities.print_info("Generating ERD json process started...")

    # if str(native_outputfile) == "None":
    #     denorm_ddl_file = utilities.Config.DENORM_NATIVE_DDL_FILE
    # else:
    #     denorm_ddl_file = native_outputfile
    #
    # ddlfile = open(denorm_ddl_file, 'wb')
    #
    # denorm_csv_file = utilities.Config.DENORM_CSV_FILE
    # csvfile = open(denorm_csv_file, 'wb')
    #
    # if str(dml_outputfile) == "None":
    #     denorm_dml_file = utilities.Config.DENORM_DML_FILE
    # else:
    #     denorm_dml_file = dml_outputfile
    #
    # dmlfile = open(denorm_dml_file, 'wb')
    treefile = open(tree_file, 'r')

    tree_list = []
    for line in treefile:
        node = str(line).lower().split(":")
        key = node[0]
        val = node[1]

        tree_list.append(line)

    # for level, node in tree_dict.iteritems():
    #     print level
    #     print node


    json_dict = {}

    jf = open(json_file, 'r')
    for line in jf:
        print line.rstrip("\n").split(":[")

    with open(json_file, 'r') as input_file:
        json_data = input_file.read()

    json_dict = json.loads(str(json_data).lower())

    # for row in json_data:
    #     print row

    # json_list =

    # def json_parse(data):
    #     d = data.strip().replace("\n\n", ",")
    #     d = '{"result":[' + d + ']}'
    #     return json.loads(d)

    # for k, v in json_dict.iteritems():
    #     print k
    #     print v

    # print json_dict
    erd_dict = []
    erd_dict.append("{")
    root_flag = 1
    prev_level = ''
    prev_parent_level = ''
    bracket_count = 0
    flower_count = 0
    root_count = 0

    dict1 = {}
    for dict in json_list.__iter__():
        dict1 = dict.copy()

    for row in tree_list:
        row_split = str(row.rstrip("\n")).lower().split(":")
        parent_level = row_split[0]
        current_level = row_split[1]
        key = row_split[2]

        if json_dict.has_key(key):
            fields = json_dict.get(key)

            if prev_level in parent_level:

                print "if prev_level:" + prev_level + " parent_level:" + parent_level + " current_level:" + current_level + " key:" + key

                if root_flag == 1:
                    print 'if root:' + str(key)
                    erd_dict.append('"name":' + '"' + str(key) + '",')
                    erd_dict.append('"columns":' + str(fields))
                    root_flag = 0
                else:
                    print 'else root:' + str(key)
                    erd_dict.append(',"children":[')
                    erd_dict.append('{')
                    print "["
                    print "{"
                    erd_dict.append('"name":' + '"' + str(key) + '",')
                    erd_dict.append('"columns":' + str(fields))
                    flower_count += 1
                    bracket_count += 1
                    print 'else root:' + str(key) + " flower_count:" + str(flower_count) + " bracket_count:" + str(bracket_count)

            elif prev_parent_level in parent_level:
                print "elif prev_parent_level:" + prev_parent_level + " parent_level:" + parent_level + " current_level:" + current_level + " key:" + key
                root_flag = 1
                if root_flag == 1:
                    print 'elif if root:' + str(key) + " flower_count:" + str(flower_count) + " bracket_count:" + str(bracket_count)
                    flower_count = flower_count - 1
                    erd_dict.append('}')
                    erd_dict.append(',{')
                    print "}"
                    print ",{"
                    erd_dict.append('"name":' + '"' + str(key) + '",')
                    erd_dict.append('"columns":' + str(fields))
                    root_flag = 0
                    root_count += 1

            else:
                print "else prev_level:" + prev_level + " parent_level:" + parent_level + " prev_parent_level:" + prev_parent_level + " parent_level:" + parent_level + " current_level:" + current_level + " key:" + key\
                      + " flower_count:" + str(flower_count) + " bracket_count:" + str(bracket_count) + " root_count:" + str(root_count)

                root_flag = 1
                if root_flag == 1:
                    for i in range(flower_count-1):
                        erd_dict.append('}')
                        erd_dict.append(']')
                        print "}"
                        print "]"

                    erd_dict.append('}')
                    print "}"
                    flower_count = 0
                    bracket_count =  bracket_count - i - 1
                    print "else bracket_count: " + str(bracket_count) + " - :" + str(i)
                    child_count = 0
                    erd_dict.append(',{')
                    print ",{"
                    erd_dict.append('"name":' + '"' + str(key) + '",')
                    erd_dict.append('"columns":' + str(fields))
                    root_count += 1
                    flower_count += 1
                    root_flag = 0
                    print 'else root:' + str(key)

        prev_level = current_level
        prev_parent_level = parent_level

    print str(key) + " flower_count:" + str(flower_count) + " bracket_count:" + str(bracket_count) + " root_count:" + str(root_count)

    erd_dict.append('}')
    print "}"
    for i in range(bracket_count):
        erd_dict.append(']')
        erd_dict.append('}')
        print "]"
        print "}"

    erd_string = "\n".join(erd_dict)
    print erd_string

    print "json file:"
    print json.dumps(erd_dict)

    dmc.core.utilities.print_info("Generating ERD json process completed...")

if __name__ == '__main__':
    main()