#!/usr/bin/python

import utilities
from dmc.core.patterns import exclude_tables_from_metadata
from dmc.core.patterns import include_tables_from_metadata

"""
 * @author n662293
 """

"""
 * Function to select anchor tables from nodes based on anchor tables list
 """

def select_anchor_tables(node_dict,anchor_tables,exclude_tables,include_tables):
    utilities.print_info("Selecting anchor tables started...")

    ex_flag, in_flag = 0, 0

    if str(exclude_tables) != "None":
        exclude_table_list = str(exclude_tables).lower().split(",")
        ex_flag = 1

    if str(include_tables) != "None":
        include_table_list = str(include_tables).lower().split(",")
        in_flag = 1

    anchors = str(anchor_tables).lower().split(",")

# loop through the anchors to perform dfs function for each present in anchor list
    anchors_dcit = {}
    for keys in anchors:
        init = 0
        visited_tbls_final = []
        visited_tbls = dfs(node_dict,node_dict[keys],init,anchors)
        for c_tbl in visited_tbls:
            ex_in_flag = 1

            if ex_flag == 1:
                ex_in_flag = exclude_tables_from_metadata(c_tbl, exclude_table_list)
            else:
                if in_flag == 1:
                    ex_in_flag = include_tables_from_metadata(c_tbl, include_table_list)
                else:
                    ex_in_flag = 0

            if ex_in_flag == 0:
                visited_tbls_final.append(c_tbl)

        anchors_dcit.setdefault(keys, sorted(set(visited_tbls_final),key=visited_tbls.index))

    utilities.print_info("Selecting anchor tables completed...")

    return anchors_dcit

"""
 * Function to implement the Depth-first search algorithm by avoiding the anchors
 """
def dfs(graph, node, init, anchors,visited =[]):
    # Initializing the visited list for every new anchor
    if init == 0:
        visited[:] =[]
    for n in node:
        if n in graph.keys():
            if n not in visited and n not in anchors:
                visited.append(n)
                init = 1
                # Recursive call on the dfs function
                dfs(graph, graph[n], init, anchors,visited)
        elif n not in anchors:
            visited.append(n)
    return visited