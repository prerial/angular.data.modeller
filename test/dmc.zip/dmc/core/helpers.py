#!/usr/bin/python

import sys

"""
 * @author n662293
 """

"""
 * Functions to check the arguments
 """
def fail(message, *args):
    print >> sys.stderr, 'Error:' , message % args
    sys.exit(1)

def pass1(message, *args):
    print >> sys.stderr, 'Note:' , message % args

def check_args(args):

    if (str(args.run).upper() == 'U'):
        pass
    elif (str(args.run).upper() == 'S'):
        if (args.erwinf is not None and args.d is not None and args.s is not None and args.a is not None):
            fail('Cannot perform denormalization if both database details and erwin file are provided, specify either -d, -s, -a options or -erwinf, -a options..............')

        if args.erwinf is not None :
            if args.a is None:
                fail('Cannot perform denormalization if anchor tables are not provided, specify with -a option..............')
        else:
            if (args.d is None and args.s is None and args.a is None):
                fail('Cannot perform denormalization if both database details and erwin file are not provided, specify either -d, -s, -a options or -erwinf, -a options..............')
            else:
                if args.d is None or args.s is None or args.a is None:
                    fail('Cannot perform denormalization if database details are not provided, make sure that -d, -s, -a options are provided..............')

            if (args.d is not None and args.s is not None and args.a is not None):
                if (args.host is None and args.usr is None and args.pwd is None) or (args.host is not None and args.usr is not None and args.pwd is not None):
                    pass
                else:
                    fail('Cannot perform denormalization if database details are not provided, make sure that -host -usr -pwd options are provided or None of them provided..............')

        if args.x is not None and args.i is not None:
            fail('Cannot perform denormalization if both exclude and include tables provided, specify one of the option..............')
    else:
        fail('Cannot perform denormalization if run type is not provided, specify either -run s for standalone or -run u for UI option..............')