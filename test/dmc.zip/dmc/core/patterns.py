import utilities

"""
 * @author n662293
 """

"""
 * Function to exclude tables from metadata for denormalization
 """
def exclude_tables_from_metadata(c_tbl,exclude_table_list):
    exclude_flag = 0

    for tbl in exclude_table_list:
        if str(c_tbl) == str(tbl):
            exclude_flag = 1
        elif (str(tbl).find("*") != -1):
            if str(tbl).index("*") == 0:
                if str(c_tbl).upper().endswith(str(tbl).upper()[1:len(str(tbl))]):
                    exclude_flag = 1
            else:
                if str(c_tbl).upper().startswith(str(tbl).upper()[0:len(str(tbl)) - 1]):
                    exclude_flag = 1

    return exclude_flag

"""
 * Function to include tables from metadata for denormalization
 """
def include_tables_from_metadata(c_tbl,include_table_list):
    include_flag = 1

    for tbl in include_table_list:
        if str(c_tbl) == str(tbl):
            include_flag = 0
        elif (str(tbl).find("*") != -1):
            if str(tbl).index("*") == 0:
                if str(c_tbl).upper().endswith(str(tbl).upper()[1:len(str(tbl))]):
                    include_flag = 0
            else:
                if str(c_tbl).upper().startswith(str(tbl).upper()[0:len(str(tbl)) - 1]):
                    include_flag = 0

    return include_flag