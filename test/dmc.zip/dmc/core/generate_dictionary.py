#!/usr/bin/python

import json
import utilities

"""
 * @author n662293
 """

"""
 * Function to generate node, node columns, ddl dictionaries
 """
def generate_dict(data_source):
    utilities.print_info("Generating dictionary started...")

    json_file = utilities.Config.JSON_FILE

    with open(json_file) as json_data:
        jdata = json.load(json_data)

    node_list = []
    node_dict = {}
    node_columns_list = []
    node_columns_dict = {}
    ddl_list = []
    ddl_dict = {}

    for i in range(len(jdata)):
        table_name_tmp = jdata[i]["table"]
        table_name = str(table_name_tmp)

        for doc in jdata[i]["fields"]:
            column_name = str(doc["column_name"])
            column_type = str(doc["column_type"])
            data_length = str(doc["size"])
            constraint_type = str(doc["constraint_type"])
            primaryKey = str(doc["primaryKey"])
            referenced_table_name = str(doc["referenced_table_name"])
            referenced_column_name = str(doc["referenced_column_name"])

            if column_type.lower() == "varchar2" or column_type.lower() == "varchar" or \
               column_type.lower() == "char" or column_type.lower() == "number" or \
               column_type.lower() == "decimal" or column_type.lower() == "double":
                column_type = column_type + "(" + data_length + ")"

            if constraint_type == "FOREIGN KEY":
                node_list.append((table_name,referenced_table_name))
                node_list.append((referenced_table_name,table_name))
                ddl_list.append((table_name, column_name, column_type, constraint_type, referenced_table_name, referenced_column_name))

            node_columns_list.append((table_name, column_name))
            ddl_list.append((table_name,column_name,column_type,constraint_type,referenced_table_name,referenced_column_name))

    for x in node_list:
        node_dict.setdefault(x[0], set()).add(x[1])

    uni_cols=[]
    for x in node_columns_list:
        if x not in uni_cols :
            uni_cols.append(x)

    for x in uni_cols:
        node_columns_dict.setdefault(x[0], []).append(x[1])

    for x in ddl_list:
        ddl_dict.setdefault(x[0], []).append(x[1] + " " + x[2] + "#" + x[3] + "," + x[4] + "," + x[5])

    # erd_dict = []
    # if str(data_source).upper() == "MYSQL":
    #     erd_dict = get_erd()

    utilities.print_info("Generating dictionary completed...")

    return node_dict, node_columns_dict, ddl_dict

# def get_erd():
#     erd_dict = [
#         {
#             "name": "Employees",
#             "columns": [
#                 {"column_type": "int", "referenced_column_name": "None", "constraint_type": "PRIMARY KEY",
#                  "column_name": "employeeid", "referenced_table_name": "None", "primaryKey": "True", "size": "11"},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "lastname", "referenced_table_name": "None", "primaryKey": "False", "size": "20"},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "firstname", "referenced_table_name": "None", "primaryKey": "False", "size": "10"},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "title", "referenced_table_name": "None", "primaryKey": "False", "size": "30"},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "titleofcourtesy", "referenced_table_name": "None", "primaryKey": "False",
#                  "size": "25"},
#                 {"column_type": "datetime", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "birthdate", "referenced_table_name": "None", "primaryKey": "False", "size": 0},
#                 {"column_type": "datetime", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "hiredate", "referenced_table_name": "None", "primaryKey": "False", "size": 0},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "address", "referenced_table_name": "None", "primaryKey": "False", "size": "60"},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "city", "referenced_table_name": "None", "primaryKey": "False", "size": "15"},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "region", "referenced_table_name": "None", "primaryKey": "False", "size": "15"},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "postalcode", "referenced_table_name": "None", "primaryKey": "False", "size": "10"},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "country", "referenced_table_name": "None", "primaryKey": "False", "size": "15"},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "homephone", "referenced_table_name": "None", "primaryKey": "False", "size": "24"},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "extension", "referenced_table_name": "None", "primaryKey": "False", "size": "4"},
#                 {"column_type": "longblob", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "photo", "referenced_table_name": "None", "primaryKey": "False", "size": 0},
#                 {"column_type": "mediumtext", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "notes", "referenced_table_name": "None", "primaryKey": "False", "size": 0},
#                 {"column_type": "int", "referenced_column_name": "employeeid", "constraint_type": "FOREIGN KEY",
#                  "column_name": "reportsto", "referenced_table_name": "employees", "primaryKey": "False", "size": "11"},
#                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "photopath", "referenced_table_name": "None", "primaryKey": "False", "size": "255"},
#                 {"column_type": "float", "referenced_column_name": "None", "constraint_type": "None",
#                  "column_name": "salary", "referenced_table_name": "None", "primaryKey": "False", "size": 0}
#             ],
#             "children": [
#                 {
#                     "name": "EmployeesTerritories",
#                     "columns": [
#                         {"column_type": "int", "referenced_column_name": "employeeid", "constraint_type": "FOREIGN KEY",
#                          "column_name": "employeeid", "referenced_table_name": "employees", "primaryKey": "False",
#                          "size": "11"},
#                         {"column_type": "varchar", "referenced_column_name": "territoryid",
#                          "constraint_type": "FOREIGN KEY", "column_name": "territoryid",
#                          "referenced_table_name": "territories", "primaryKey": "False", "size": "20"}
#                     ],
#                     "children": [
#                         {
#                             "name": "Territories",
#                             "columns": [
#                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                  "constraint_type": "PRIMARY KEY", "column_name": "territoryid",
#                                  "referenced_table_name": "None", "primaryKey": "True", "size": "20"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "territorydescription", "referenced_table_name": "None",
#                                  "primaryKey": "False", "size": "50"},
#                                 {"column_type": "int", "referenced_column_name": "regionid",
#                                  "constraint_type": "FOREIGN KEY", "column_name": "regionid",
#                                  "referenced_table_name": "region", "primaryKey": "False", "size": "11"}
#                             ],
#                             "children": [
#                                 {
#                                     "name": "Region",
#                                     "columns": [
#                                         {"column_type": "int", "referenced_column_name": "None",
#                                          "constraint_type": "PRIMARY KEY", "column_name": "regionid",
#                                          "referenced_table_name": "None", "primaryKey": "True", "size": "11"},
#                                         {"column_type": "varchar", "referenced_column_name": "None",
#                                          "constraint_type": "None", "column_name": "regiondescription",
#                                          "referenced_table_name": "None", "primaryKey": "False", "size": "50"}
#                                     ],
#
#                                 }
#                             ]
#                         }
#                     ]
#                 },
#                 {
#                     "name": "Orders",
#                     "columns": [
#                         {"column_type": "int", "referenced_column_name": "None", "constraint_type": "PRIMARY KEY",
#                          "column_name": "orderid", "referenced_table_name": "None", "primaryKey": "True", "size": "11"},
#                         {"column_type": "varchar", "referenced_column_name": "customerid",
#                          "constraint_type": "FOREIGN KEY", "column_name": "customerid",
#                          "referenced_table_name": "customers", "primaryKey": "False", "size": "5"},
#                         {"column_type": "int", "referenced_column_name": "employeeid", "constraint_type": "FOREIGN KEY",
#                          "column_name": "employeeid", "referenced_table_name": "employees", "primaryKey": "False",
#                          "size": "11"},
#                         {"column_type": "datetime", "referenced_column_name": "None", "constraint_type": "None",
#                          "column_name": "orderdate", "referenced_table_name": "None", "primaryKey": "False", "size": 0},
#                         {"column_type": "datetime", "referenced_column_name": "None", "constraint_type": "None",
#                          "column_name": "requireddate", "referenced_table_name": "None", "primaryKey": "False",
#                          "size": 0},
#                         {"column_type": "datetime", "referenced_column_name": "None", "constraint_type": "None",
#                          "column_name": "shippeddate", "referenced_table_name": "None", "primaryKey": "False",
#                          "size": 0},
#                         {"column_type": "int", "referenced_column_name": "shipperid", "constraint_type": "FOREIGN KEY",
#                          "column_name": "shipvia", "referenced_table_name": "shippers", "primaryKey": "False",
#                          "size": "11"},
#                         {"column_type": "decimal", "referenced_column_name": "None", "constraint_type": "None",
#                          "column_name": "freight", "referenced_table_name": "None", "primaryKey": "False",
#                          "size": "10,4"},
#                         {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                          "column_name": "shipname", "referenced_table_name": "None", "primaryKey": "False",
#                          "size": "40"},
#                         {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                          "column_name": "shipaddress", "referenced_table_name": "None", "primaryKey": "False",
#                          "size": "60"},
#                         {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                          "column_name": "shipcity", "referenced_table_name": "None", "primaryKey": "False",
#                          "size": "15"},
#                         {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                          "column_name": "shipregion", "referenced_table_name": "None", "primaryKey": "False",
#                          "size": "15"},
#                         {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                          "column_name": "shippostalcode", "referenced_table_name": "None", "primaryKey": "False",
#                          "size": "10"},
#                         {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                          "column_name": "shipcountry", "referenced_table_name": "None", "primaryKey": "False",
#                          "size": "15"}
#                     ],
#                     "children": [
#                         {
#                             "name": "OrdersDetails",
#                             "columns": [
#                                 {"column_type": "int", "referenced_column_name": "None",
#                                  "constraint_type": "PRIMARY KEY", "column_name": "orderid",
#                                  "referenced_table_name": "None", "primaryKey": "True", "size": "11"},
#                                 {"column_type": "int", "referenced_column_name": "orderid",
#                                  "constraint_type": "FOREIGN KEY", "column_name": "orderid",
#                                  "referenced_table_name": "orders", "primaryKey": "False", "size": "11"},
#                                 {"column_type": "int", "referenced_column_name": "None",
#                                  "constraint_type": "PRIMARY KEY", "column_name": "productid",
#                                  "referenced_table_name": "None", "primaryKey": "True", "size": "11"},
#                                 {"column_type": "int", "referenced_column_name": "productid",
#                                  "constraint_type": "FOREIGN KEY", "column_name": "productid",
#                                  "referenced_table_name": "products", "primaryKey": "False", "size": "11"},
#                                 {"column_type": "decimal", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "unitprice", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "10,4"},
#                                 {"column_type": "smallint", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "quantity", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "2"},
#                                 {"column_type": "double", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "discount", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "8,0"}
#                             ],
#
#                             "children": [
#                                 {
#                                     "name": "Products",
#                                     "columns": [
#                                         {"column_type": "int", "referenced_column_name": "None",
#                                          "constraint_type": "PRIMARY KEY", "column_name": "productid",
#                                          "referenced_table_name": "None", "primaryKey": "True", "size": "11"},
#                                         {"column_type": "varchar", "referenced_column_name": "None",
#                                          "constraint_type": "None", "column_name": "productname",
#                                          "referenced_table_name": "None", "primaryKey": "False", "size": "40"},
#                                         {"column_type": "int", "referenced_column_name": "supplierid",
#                                          "constraint_type": "FOREIGN KEY", "column_name": "supplierid",
#                                          "referenced_table_name": "suppliers", "primaryKey": "False", "size": "11"},
#                                         {"column_type": "int", "referenced_column_name": "categoryid",
#                                          "constraint_type": "FOREIGN KEY", "column_name": "categoryid",
#                                          "referenced_table_name": "categories", "primaryKey": "False", "size": "11"},
#                                         {"column_type": "varchar", "referenced_column_name": "None",
#                                          "constraint_type": "None", "column_name": "quantityperunit",
#                                          "referenced_table_name": "None", "primaryKey": "False", "size": "20"},
#                                         {"column_type": "decimal", "referenced_column_name": "None",
#                                          "constraint_type": "None", "column_name": "unitprice",
#                                          "referenced_table_name": "None", "primaryKey": "False", "size": "10,4"},
#                                         {"column_type": "smallint", "referenced_column_name": "None",
#                                          "constraint_type": "None", "column_name": "unitsinstock",
#                                          "referenced_table_name": "None", "primaryKey": "False", "size": "2"},
#                                         {"column_type": "smallint", "referenced_column_name": "None",
#                                          "constraint_type": "None", "column_name": "unitsonorder",
#                                          "referenced_table_name": "None", "primaryKey": "False", "size": "2"},
#                                         {"column_type": "smallint", "referenced_column_name": "None",
#                                          "constraint_type": "None", "column_name": "reorderlevel",
#                                          "referenced_table_name": "None", "primaryKey": "False", "size": "2"},
#                                         {"column_type": "bit", "referenced_column_name": "None",
#                                          "constraint_type": "None", "column_name": "discontinued",
#                                          "referenced_table_name": "None", "primaryKey": "False", "size": "1"}
#                                     ],
#                                     "children": [
#                                         {
#                                             "name": "Suppliers",
#                                             "columns": [
#                                                 {"column_type": "int", "referenced_column_name": "None",
#                                                  "constraint_type": "PRIMARY KEY", "column_name": "supplierid",
#                                                  "referenced_table_name": "None", "primaryKey": "True", "size": "11"},
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "companyname",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": "40"},
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "contactname",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": "30"},
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "contacttitle",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": "30"},
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "address",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": "60"},
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "city",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": "15"},
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "region",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": "15"},
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "postalcode",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": "10"},
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "country",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": "15"},
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "phone",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": "24"},
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "fax",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": "24"},
#                                                 {"column_type": "mediumtext", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "homepage",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": 0}
#                                             ],
#
#                                         },
#                                         {
#                                             "name": "Categories",
#                                             "columns": [
#                                                 {"column_type": "int", "referenced_column_name": "None",
#                                                  "constraint_type": "PRIMARY KEY", "column_name": "categoryid",
#                                                  "referenced_table_name": "None", "primaryKey": "True", "size": "11"},
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "categoryname",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": "15"},
#                                                 {"column_type": "mediumtext", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "description",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": 0},
#                                                 {"column_type": "longblob", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "picture",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": 0}
#                                             ]}
#                                     ]
#                                 }]
#                         }
#                         ,
#                         {
#                             "name": "Customers",
#                             "columns": [
#                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                  "constraint_type": "PRIMARY KEY", "column_name": "customerid",
#                                  "referenced_table_name": "None", "primaryKey": "True", "size": "5"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "companyname", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "40"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "contactname", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "30"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "contacttitle", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "30"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "address", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "60"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "city", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "15"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "region", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "15"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "postalcode", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "10"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "country", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "15"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "phone", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "24"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "fax", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "24"}
#                             ],
#                             "children": [
#                                 {
#                                     "name": "CustomersCustomersDemo",
#                                     "columns": [
#                                         {"column_type": "varchar", "referenced_column_name": "None",
#                                          "constraint_type": "PRIMARY KEY", "column_name": "customerid",
#                                          "referenced_table_name": "None", "primaryKey": "True", "size": "5"},
#                                         {"column_type": "varchar", "referenced_column_name": "customerid",
#                                          "constraint_type": "FOREIGN KEY", "column_name": "customerid",
#                                          "referenced_table_name": "customers", "primaryKey": "False", "size": "5"},
#                                         {"column_type": "varchar", "referenced_column_name": "None",
#                                          "constraint_type": "PRIMARY KEY", "column_name": "customertypeid",
#                                          "referenced_table_name": "None", "primaryKey": "True", "size": "10"},
#                                         {"column_type": "varchar", "referenced_column_name": "customertypeid",
#                                          "constraint_type": "FOREIGN KEY", "column_name": "customertypeid",
#                                          "referenced_table_name": "customerdemographics", "primaryKey": "False",
#                                          "size": "10"}
#                                     ],
#                                     "children": [
#                                         {
#                                             "name": "CustomerDemographics",
#                                             "columns": [
#                                                 {"column_type": "varchar", "referenced_column_name": "None",
#                                                  "constraint_type": "PRIMARY KEY", "column_name": "customertypeid",
#                                                  "referenced_table_name": "None", "primaryKey": "True", "size": "10"},
#                                                 {"column_type": "mediumtext", "referenced_column_name": "None",
#                                                  "constraint_type": "None", "column_name": "customerdesc",
#                                                  "referenced_table_name": "None", "primaryKey": "False", "size": 0}
#                                             ],
#
#                                         }
#                                     ]
#                                 }
#                             ]
#                         },
#                         {
#                             "name": "Shippers",
#                             "columns": [
#                                 {"column_type": "int", "referenced_column_name": "None",
#                                  "constraint_type": "PRIMARY KEY", "column_name": "shipperid",
#                                  "referenced_table_name": "None", "primaryKey": "True", "size": "11"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "companyname", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "40"},
#                                 {"column_type": "varchar", "referenced_column_name": "None", "constraint_type": "None",
#                                  "column_name": "phone", "referenced_table_name": "None", "primaryKey": "False",
#                                  "size": "24"}
#                             ]
#                         }
#                     ]}
#             ]
#         }
#     ]
#
#     return erd_dict
#
