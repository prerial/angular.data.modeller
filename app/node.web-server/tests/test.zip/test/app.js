angular.module('dmcviews', []);
angular.module('dmc.utils', []);
angular.module('dmc.directives', []);
angular.module('app.dmc', ['ngRoute', 'ngMessages', 'ngAnimate', 'dmc.directives', 'dmc.utils', 'dmcviews'])
    .constant('Messaging', {
        'error': {
            "appTitle": "DMO Error:",
            "validation": {
                "input": {
                    "inputTitle":"Input Error",
                    "MySQL" : "Selection of Data Source and Source Database options are wrong, please select MySQL",
                    "Teradata" : "Selection of Data Source and Source Database options are wrong, please select Teradata"
                }
            },
            "serverTitle": "Server Error:",
            "loginErrorMsg": "Incorrect Username/Password !",
            "anchorsErrorMsg": "Please select at least one Anchor or Include Table.",
            "serverErrorMsg": "An unexpected error has occurred\nPlease check server connection."
        },
        'success': {
            "resetMsg": "All data was reset. Please select Tables\' data and click Submit button."

        }
    })
    .constant('Colors', {
        'fillColors': {
            "default": "black",
            "anchor": "darkred",
            "include": "darkgreen",
            "exclude": "darkblue"
        },
        'backgroundColors': {
            "default": "rgb(239, 239, 239)",
            "anchor": "rgb(255,153,153)",
            "include": "rgb(144, 238, 144)",
            "exclude": "rgb(176, 196, 222)"
        }
    })
    .constant('Urls', {
        'authenticate': angular.testmode? 'data/datasource.json' : angular.restUrl + '/dmc/v1.0/schemas/authenticate',
        'login': angular.testmode? 'data/datasource.json' : angular.restUrl + '/dmc/v1.0/schemas/login',
        'logout': angular.testmode? 'data/datasource.json' : angular.restUrl + '/dmc/v1.0/schemas/logout',
        'getDataSource': angular.testmode? 'data/datasource.json' : angular.restUrl + '/dmc/v1.0/schemas/getdatasource',
        'getDatabases': angular.testmode? 'data/datasource.json' : angular.restUrl + '/dmc/v1.0/schemas/getdatabases',
        'getConnectionsData': angular.testmode? 'data/connections.json' : angular.restUrl + '/dmc/v1.0/schemas/getconnections',
        'saveConnection': angular.testmode? 'data/success.json' : angular.restUrl + '/dmc/v1.0/schemas/saveconnection',
        'deleteConnection': angular.testmode? 'data/success.json' : angular.restUrl + '/dmc/v1.0/schemas/deleteconnection',
        'getDashboardGridData': angular.testmode? 'data/erd.json' : angular.restUrl + '/dmc/v1.0/schemas',
        'getErdData': angular.testmode? 'data/erd.json' : angular.restUrl + '/dmc/v1.0/schemas/schema_id',
        'getErdAnchorData': angular.testmode? 'data/denorm_json_ddl_dml.json' : angular.restUrl + '/dmc/v1.0/schemas/denorm'
    })
    .config([ '$locationProvider', '$routeProvider',

        function( $locationProvider, $routeProvider) {
            $locationProvider.hashPrefix('');
            $routeProvider
                .when('/login', {
                    template: '<login-splash></login-splash>'
                })
                .when('/connections', {
                    template: '<connections></connections>'
                })
                .when('/datamodel', {
                    template: '<datamodel></datamodel>'
                })
                .when('/anchormodel', {
                    template: '<anchormodel></anchormodel>'
                })
                .when('/source', {
                    template: '<source-schema></source-schema>'
                })
                .otherwise({redirectTo: '/login'});
        }])
    .controller('AppController',['$scope', '$location', '$timeout', 'Messaging', 'notificationService', 'UtilsService', 'CommonRequestService',
        function($scope, $location, $timeout, messaging, notification, utilsService, commonRequestService){

        $scope.isLogon = false;
        $scope.users = [];
        $scope.isActive = function (viewLocation) {
            return viewLocation === $location.path();
        };
        $scope.logout = function () {
            var reqParam = {'requestType': 'logout', 'data': {'authtoken': utilsService.getUserToken()}};
            commonRequestService.getRequestDataQueryString(reqParam)
                .then(function (resp) {
                    if (resp.data.status === 'success') {
                        utilsService.setUserToken(null);
                        $location.url('/login');
                    } else {
                        notification.notify(utilsService.setErrorNotification(messaging.error.appTitle, resp.data.message));
                        utilsService.hideSpinner();
                    }
                }).catch(function () {
                notification.notify(utilsService.setErrorNotification(messaging.error.serverTitle, messaging.error.serverErrorMsg ));
                utilsService.hideSpinner();
            });
        };
        $scope.$on('authenticated', function() {
            $scope.isLogon = true;
        });
        $scope.$on('$routeChangeStart', function(event, next) {
            notification.removeNotifications();
            utilsService.hideSpinner();
            if(next.$$route && next.$$route.originalPath === '/login' && $scope.isLogon){
                $scope.isLogon = false;
                $location.path('/login');
            }
            $scope.$broadcast("clearPopups");
            if(!$scope.isLogon){
                $location.path('/login');
            }else{
                var reqParam = {'requestType': 'authenticate', 'data': {'authtoken': utilsService.getUserToken()}};
                commonRequestService.getRequestDataQueryString(reqParam)
                    .then(function (resp) {
                        if (resp.data.status !== 'success') {
                            notification.notify(utilsService.setErrorNotification(messaging.error.appTitle, resp.data.message));
                            utilsService.hideSpinner();
                            $timeout(function(){
                                $location.url('/login');
                            },3000);
                        }
                    }).catch(function () {
                        notification.notify(utilsService.setErrorNotification(messaging.error.serverTitle, messaging.error.serverErrorMsg ));
                        utilsService.hideSpinner();
                });

            }
        });

    }]);


