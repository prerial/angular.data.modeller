(function(){
    "use strict";

    angular.module('dmc.utils').factory('UtilsService', function() {
        var user = {
            'username': null,
            'usertoken': null
        };
        return {
            errorConfig: {
                styling: 'bootstrap3',
                type: 'error'
            },
            setUserToken: function(token){
                user.usertoken = token;
            },
            getUserToken: function(){
                return user.usertoken;
            },
            setErrorNotification: function(title, msg){
                this.errorConfig['title'] = title;
                this.errorConfig['text'] = msg;
                this.errorConfig['hide'] = false;
                return this.errorConfig;
            },
            setErrorNotificationHide: function(title, msg){
                this.errorConfig['title'] = title;
                this.errorConfig['text'] = msg;
                this.errorConfig['hide'] = true;
                return this.errorConfig;
            },
            showSpinner : function() {
                $('#dmc-back-container').show();
                $('.dmc-spinner').show();
            },
            hideSpinner : function() {
                $('#dmc-back-container').hide();
                $('.dmc-spinner').hide();
            },
            makeUnselectable: function(node) {
                if (node.nodeType === 1) {
                    node.setAttribute("unselectable", "on");
                }
                var child = node.firstChild;
                while (child) {
                    this.makeUnselectable(child);
                    child = child.nextSibling;
                }
            }

        };

    });

})();
