(function() {
    "use strict";

    angular.module('app.dmc').component('datamodel', {
        templateUrl: 'views/dataModelView.html',
        controller: 'DataModelController'

    });
    angular.module('app.dmc').controller('DataModelController', ['$scope', '$location', '$timeout', 'Messaging', 'notificationService', 'Colors', 'UtilsService', 'messageService', 'CommonRequestService', 'GraphService',
        function($scope, $location, $timeout, messaging, notification, colors, utilsService, messageService, commonRequestService, graphService) {

            var self = this;
            this.dblclicked = false;
            this.selectedEl = undefined;
            this.selectedNode = undefined;
            this.data = [];
            this.anchors = [];
            var fillColors = colors.fillColors;
            var backgroundColors = colors.backgroundColors;
            this.anchoroot = {
                type: 'anchor', // 'anchor','include','exclude'
                selected_nodes:{},
 //               erdjson: '',
                anchor: {},
                include: {},
                exclude: {},
                tables_anchor:[],
                tables_include:[],
                tables_exclude:[],
                reset: function(){
                    this.type = 'anchor';
                    this.anchor = {};
                    this.include = {};
                    this.exclude = {};
                    this.tables_anchor = [];
                    this.tables_include = [];
                    this.tables_exclude = [];
                    for(var key in this.selected_nodes){
                        this.selected_nodes[key].el.css('fill', fillColors['default']);
                        this.selected_nodes[key].node['color'] = 'default';
                    }
                    this.selected_nodes = {};
                },
                toQueryString: function(obj){
                    var parts = [];
                    for (var i in obj) {
                        if (obj.hasOwnProperty(i)) {
                            parts.push(obj[i]);
//                            parts.push(encodeURIComponent(obj[i]));
                        }
                    }
                    return parts.join(",");
                },
                isEmpty: function(){
                    var blnEmpty = true;
                    if ((this.tables_anchor.length !== 0 && this.tables_anchor[0] !== '') || (this.tables_include.length !== 0 && this.tables_include[0] !== '') ){
                        blnEmpty = false;
                    }
                    return blnEmpty;
                },
                flatten: function(){
                    if(Object.keys(this.anchor).length > 0 || Object.keys(this.include).length > 0 || Object.keys(this.exclude).length > 0){
                        this.tables_anchor.push(this.toQueryString(this.anchor));
                        this.tables_include.push(this.toQueryString(this.include));
                        this.tables_exclude.push(this.toQueryString(this.exclude));
                        return 'anchors=' + this.tables_anchor[0] + '&tables_include=' + this.tables_include[0] + '&tables_exclude=' + this.tables_exclude[0];// + '&erdjson=' + this.erdjson;
                    }
                }
            };

            $scope.$on('toggleCollapse', function(){
                self.hideTableView();
            });

            $scope.$on('hideTable', function(evt, el, node){
                self.dblclicked = true;
                el.attr("unselectable", "on");
                utilsService.makeUnselectable(el[0]);
                el.css('fill', fillColors[self.anchoroot.type]);
                node['color'] = self.anchoroot.type;
                self.hideTableView();
                $timeout(function(){
                    self.dblclicked = false;
                }, 500);
                self.setAnchors(node, el, true);
            });

            $scope.$on('showTable', function(evt, el, node){
                self.selectedEl = el;
                self.selectedNode = node;
                $timeout(function(){
                    if(!self.dblclicked){
                        var chkSelect = $('#table-selection')[0];
                        var chkSelectAll = $('#field-select-all');
                        var tblContainer = $('#table-container');
                        if(node['color']){
                            tblContainer.css('background-color', backgroundColors[node['color']]);
                            node['color'] === 'default'? chkSelect.checked =  false : chkSelect.checked =  true;
                        }else{
                            node['color'] = 'default';
                            tblContainer.css('background-color', backgroundColors['default']);
                            chkSelect.checked = false;
                        }
                        tblContainer.css('transition', 'all 800ms').css('display', 'block').css('top', node.x-20).css('left', node.y);
                        $('#table-title').html(node.name);
                        $('#table-fields').html('');
                        $('.chk-select-edit').html('Edit');
                        node.columns.forEach(function(item){
                            var chk = $('<input class="table-fields-chk" id="item.name" type="checkbox" checked/>');
                            var li = $('<li class="list-group-item"></li>');
                            var title = $('<span style="margin-left:8px">'+item.name+'</span>');
                            li.append(chk).append(title);
                            $('#table-fields').append(li);
                        });
                        chkSelectAll.hide();
                        chkSelectAll[0].checked = true;
                    }
                }, 500)
            });

            this.showEdit = function (evt) {
                var el = evt.target;
                if($(el).html() === 'Edit'){
                    $('.table-fields-chk').show();
                    $('#field-select-all').show();
                    $(el).html('Done');
                }else{
                    $('.table-fields-chk').hide();
                    $('#field-select-all').hide();
                    $(el).html('Edit')
                }
            };

            this.toggleSelection = function(){
                var arr = $('.table-fields-chk');
                var checked = $('#field-select-all')[0].checked;
                arr.each(function(idx, chk){
                    chk.checked = checked;
                });
            };

            this.hideTableView = function () {
                $('#table-container').css('display', 'none');
            };

            this.toggleBackground = function (evt) {
                var selected = $(evt.target)[0].checked;
                var el = $('#table-container');
                var blnAdd = false;
                if(selected){
                    $(self.selectedEl).css('fill', fillColors[self.anchoroot.type]);
                    $(self.selectedNode).attr('color', self.anchoroot.type);
                    el.css('background-color', backgroundColors[self.anchoroot.type]);
                    blnAdd = true;
                }else{
                    $(self.selectedEl).css('fill', fillColors['default']);
                    $(self.selectedNode).attr('color', 'default');
                    el.css('background-color', backgroundColors['default']);
                }
                self.setAnchors(self.selectedNode, self.selectedEl, blnAdd);
            };

            this.setAnchors = function(node, el, blnAdd){
                if(blnAdd){
                    Object.defineProperty(self.anchoroot[self.anchoroot.type], node['name'], {
                        writable: true,
                        enumerable: true,
                        configurable: true,
                        value: node['name']
                    });
                    self.anchoroot.selected_nodes[node['name']] = {'el':el, 'node': node};
                }else{
                    delete self.anchoroot[self.anchoroot.type][node['name']];
                    delete self.anchoroot.selected_nodes[node['name']];
                }
            };

            utilsService.showSpinner();

            this.resetAnchorsForm = function(){
                self.hideTableView();
                self.anchoroot.reset();
                notification.success(messaging.success.resetMsg);
                $('.ui-pnotify').css('top', '110px')
            };

            this.submitForm = function(){
                self.anchors = [];
                self.anchors.push(self.anchoroot.flatten());
//                this.anchors.push(encodeURIComponent(this.anchoroot.flatten()));
                if(self.anchoroot.isEmpty()){
                    notification.removeNotifications();
                    notification.notify(utilsService.setErrorNotificationHide(messaging.error.appTitle, messaging.error.anchorsErrorMsg));
                    utilsService.hideSpinner();
                }else{
                    messageService.addMessage(self.anchors[0]);
                    $location.path('/anchormodel');
                }
            };

            var formdata = messageService.getSource();
            if(!formdata){
                utilsService.hideSpinner();
                $location.path('/login');
                return;
            }
            var data = {'requestType': 'getErdData', 'data': formdata};
            commonRequestService.getRequestDataQueryString(data)
                .then(function(resp){
                    if(resp.data.status === 'success') {
                        self.resetAnchorsForm();
//                        self.anchoroot.erdjson = JSON.stringify(resp.data);
                        var erData = resp.data.payload;
                        $timeout(function () {
                            graphService.buildGraph(erData, false);
                            utilsService.hideSpinner();
                        }, 500);
                    }else{
                        notification.notify(utilsService.setErrorNotification(messaging.error.appTitle, resp.data.message));
                        utilsService.hideSpinner();
                    }
                }).catch( function(){
                    notification.notify(utilsService.setErrorNotification(messaging.error.serverTitle, messaging.error.serverErrorMsg ));
                    utilsService.hideSpinner();
            });

        }]);
})();
