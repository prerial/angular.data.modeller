(function() {
    "use strict";

    angular.module('app.dmc').component('loginSplash', {
        templateUrl: 'views/loginAdminView.html',
        controller: 'LoginController'
    });
    angular.module('app.dmc').controller('LoginController', ['$scope','$rootScope', '$location', 'Messaging', 'notificationService', 'UtilsService', 'LoginService', 'CommonRequestService',
          function($scope, $rootScope, $location, messaging, notification, utilsService, loginService, commonRequestService) {

              $scope.formSubmit = function(formdata) {
                  notification.removeNotifications();
                  var reqParam = {'requestType': 'login', 'data': {'username': formdata.username, 'password': formdata.password}};
                  commonRequestService.getRequestDataQueryString(reqParam)
                      .then(function (resp) {
                          if (resp.data.status === 'success') {
                              utilsService.setUserToken(resp.data.payload.authtoken);
                              $rootScope.$broadcast('authenticated');
                              $scope.error = '';
                              $scope.username = '';
                              $scope.password = '';
                              $location.url('/source');
                          } else {
                              notification.notify(utilsService.setErrorNotification(messaging.error.appTitle, resp.data.message));
                              utilsService.hideSpinner();
                          }
                      }).catch(function () {
                          notification.notify(utilsService.setErrorNotification(messaging.error.serverTitle, messaging.error.serverErrorMsg));
                          utilsService.hideSpinner();
                  });
              };
        }]);

})();
