import json
import MySQLdb

server = '169.97.78.88'
user = 'a_crts_nd'
password = 'a_crts_nd'
database = 'dmc'


class DmcDB(object):

    @staticmethod
    def save_connections(data, uname):
        connection = MySQLdb.connect(server, user, password, database)
        c = connection.cursor()
        c.execute("""insert into Connections (username,conn_name,conn_username,conn_password,conn_string,conn_db,conn_schema) values (%s, %s, %s, %s, %s, %s, %s)""",
                  (uname, data['conn_name'], data['conn_username'], data['conn_password'], data['conn_string'], data['conn_db'], data['conn_schema']))
        connection.commit()
        c.close()
        connection.close()

    @staticmethod
    def update_connection(data):
        connection = MySQLdb.connect(server, user, password, database)
        c = connection.cursor()
        c.execute("""
           UPDATE Connections
           SET username=(%s),conn_name=(%s),conn_username=(%s),conn_password=(%s),conn_string=(%s),conn_db=(%s),conn_schema=(%s)
           WHERE ID=(%s)
        """, (data["username"], data["conn_name"], data["conn_username"], data["conn_password"], data["conn_string"], data["conn_db"], data["conn_schema"], str(data["ID"])))
        connection.commit()
        c.close()
        connection.close()

    @staticmethod
    def delete_connection(rec_id, database_name):
        connection = MySQLdb.connect(server, user, password, database)
        c = connection.cursor()
        c.execute("delete from Connections where ID=" + rec_id)
        connection.commit()
        c.close()
        connection.close()

    @staticmethod
    def get_data_json_single(execstr):
        connection = MySQLdb.connect(server, user, password, database)
        c = connection.cursor()
        c.execute(execstr)
        r = [dict((c.description[i][0], value) for i, value in enumerate(row)) for row in c.fetchall()]
        c.close()
        connection.close()
        return json.dumps(r)

    @staticmethod
    def get_data_json(root, execstr):
        connection = MySQLdb.connect(server, user, password, database)
        c = connection.cursor()
        c.execute(execstr)
        r = [dict((c.description[i][0], value) for i, value in enumerate(row)) for row in c.fetchall()]
        c.close()
        connection.close()
        return '"' + root + '": ' + json.dumps(r)

    @staticmethod
    def wrap_response(self, list_arr):
        s = ","
        seq = []
        for label in list_arr:
            seq.append(self.get_data_json(label['name'], label['str']))
        return s.join(seq)

