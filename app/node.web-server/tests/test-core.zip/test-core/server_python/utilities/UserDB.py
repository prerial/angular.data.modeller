import json
import MySQLdb

server = '169.97.78.88'
username = 'a_crts_nd'
password = 'a_crts_nd'
database = 'dmc'


class UserDB(object):

    @staticmethod
    def get_user_credentials(usernm):
        connection = MySQLdb.connect(server, username, password, database)
        c = connection.cursor()
        try:
            c.execute("select * from DMO_Users where user_name='"+usernm+"'")
            user = [dict((c.description[i][0], value) for i, value in enumerate(row)) for row in c.fetchall()]
            connection.commit()
        except Exception as e:
            user = []
        c.close()
        connection.close()
        return user

    @staticmethod
    def get_user_name(token):
        connection = MySQLdb.connect(server, username, password, database)
        c = connection.cursor()
        try:
            c.execute("select user_name from DMO_Sessions where user_token='" + token + "'")
            user = [dict((c.description[i][0], value) for i, value in enumerate(row)) for row in c.fetchall()]
            user_name = user[0]['user_name']
            connection.commit()
        except Exception as e:
            user_name = ''
        c.close()
        connection.close()
        return user_name

    @staticmethod
    def get_token(usernm):
        connection = MySQLdb.connect(server, username, password, database)
        c = connection.cursor()
        c.execute("select * from DMO_Users where user_name='"+usernm+"'")
        user = [dict((c.description[i][0], value) for i, value in enumerate(row)) for row in c.fetchall()]
        connection.commit()
        c.close()
        connection.close()
        return user

    @staticmethod
    def set_session(usernm, token):
        connection = MySQLdb.connect(server, username, password, database)
        c = connection.cursor()
        c.execute("""insert into DMO_Sessions (user_name, user_token, expire) values (%s, %s, %s)""",
                  (usernm, token, 5))
        connection.commit()
        c.close()
        connection.close()

    @staticmethod
    def delete_session(token):
        connection = MySQLdb.connect(server, username, password, database)
        c = connection.cursor()
        c.execute("delete from DMO_Sessions where user_token='" + token + "'")
        connection.commit()
        c.close()
        connection.close()

    @staticmethod
    def delete_session_by_name(name):
        connection = MySQLdb.connect(server, username, password, database)
        c = connection.cursor()
        c.execute("delete from DMO_Sessions where user_name='" + name + "'")
        print name
        connection.commit()
        c.close()
        connection.close()
