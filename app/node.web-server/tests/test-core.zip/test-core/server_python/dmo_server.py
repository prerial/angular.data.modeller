#!/usr/bin/python

import json
from uuid import uuid4
from flask import Flask, request, Response
from server_python.utilities.DmcDB import DmcDB
from server_python.utilities.UserDB import UserDB
from server_python.core.main import main

"""
 * @author n662293
 """

dmcdb = DmcDB()
userdb = UserDB()

app = Flask(__name__)
app.config.from_object(__name__)

#  Request No1 : dmc index html
#@app.route('/')
#def dmc_webserver():
#    return render_template('index.html')

Session = {}
User = {}


#  Request: to retrive connections
@app.route('/dmc/v1.0/schemas/authenticate', methods=['GET'])
def authenticate():
    username = userdb.get_user_name(str(request.args.get('authtoken')))
    if username == '':
        resp = Response('{"status": "error", "message": "Your Session Has Ended. You\'ll have to sign on again.", "payload": []}')
        print "Request to authenticate: Ended."
    else:
        resp = Response('{"status": "success", "message": "Your Session isalive.", "payload": []}')
        print "Request to authenticate: Good."
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp


@app.route('/dmc/v1.0/schemas/login', methods=['GET', 'POST'])
def do_login():
    try:
        userobj = userdb.get_user_credentials(request.args.get('username'))[0]
        User[userobj.get('user_name')] = userobj
        if request.args.get('password') == userobj['user_password']:
            #token = (request.args.get('username')+request.args.get('password')).encode('base64', 'strict')
            userdb.delete_session_by_name(request.args.get('username'))
            token = str(uuid4())
            userdb.set_session(request.args.get('username'), token)
            js = json.dumps({"status": "success", "message": "Logged In!!!", "payload": {"authtoken": token}})
            print "Logged In!!!"
        else:
            message = 'Wrong password!'
            js = json.dumps({"status": "error", "message": message, "payload": {}})
    except Exception as e:
        message = 'Wrong user name!'
        js = json.dumps({"status": "error", "message": message, "payload": {}})
    resp = Response(js)
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp


@app.route("/dmc/v1.0/schemas/logout", methods=['GET', 'POST'])
def do_logout():
    userdb.delete_session(str(request.args.get('authtoken')))
    resp = Response('{"status": "success", "message": "Logged out!!!", "payload": {}}')
    print "Logged out!!!"
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp


#  Request No2 : to render json schema for visulization.
@app.route('/dmc/v1.0/schemas/schema_id', methods=['GET'])
def schemas():
    print "Request No2 : to render json schema visulization"
    erd_json = main(request.url)
    resp = Response(erd_json)
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp

#  Request No3 : to render denormalize json schema, ddl, dml.
@app.route('/dmc/v1.0/schemas/denorm', methods=['GET'])
def denorm():
    print "Request No3 : to render denormalize json schema, ddl, dml."
    denorm_json = main(request.url)
    resp = Response(denorm_json)
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp

#  Request: to retrive Data Source
@app.route('/dmc/v1.0/schemas/getdatasource', methods=['GET'])
def get_datasource():
    print "Request: to retrive getdatasource."
    username = userdb.get_user_name(str(request.args.get('authtoken')))
    data_labels = [{'name': 'dataSource', 'str': 'SELECT * FROM Connections where username="' + username + '";'}, {'name': 'dataModelType', 'str': '''SELECT * FROM DataModelTypes;'''}, {'name': 'databaseSource', 'str': '''SELECT * FROM SourceDatabase;'''}, {'name': 'databaseTarget', 'str': '''SELECT * FROM TargetDatabase;'''}]
    resp = Response('{"status": "success", "message": "", "payload": {' + dmcdb.wrap_response(dmcdb, data_labels) + '}}')
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp

@app.route('/dmc/v1.0/schemas/saveconnection', methods=['GET', 'POST'])
def saveconnection():
    print "Request: save connections."
    data = json.loads(request.data)['data']
    uname = userdb.get_user_name(str(data['authtoken']))
    if str(data["type"]) == 'save':
        dmcdb.save_connections(data, uname)
        resp = Response('{"status": "success","message": "Record was successfully saved!",  "payload": []}')
    else:
        dmcdb.update_connection(data)
        resp = Response('{"status": "success","message": "Record was successfully updated!",  "payload": []}')
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp


@app.route('/dmc/v1.0/schemas/deleteconnection', methods=['GET', 'POST'])
def deleteconnection():
    print "Request: delete connections."
    data = json.loads(request.data)
    dmcdb.delete_connection(str(data['data']), 'Connections')
    resp = Response('{"status": "success","message": "Record was successfully deleted!",  "payload": []}')
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp


#  Request: to retrive connections
@app.route('/dmc/v1.0/schemas/getconnections', methods=['GET'])
def getconnections():
    print "Request: to retrive connections."
    username = userdb.get_user_name(str(request.args.get('authtoken')))
    sql = "SELECT * FROM Connections where username='" + username + "';"
    resp = Response('{"status": "success", "message": "", "payload": ' + dmcdb.get_data_json_single(sql) + '}')
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp


#  Request: to retrive databases
@app.route('/dmc/v1.0/schemas/getdatabases', methods=['GET'])
def getdatabases():
    print "Request: to retrive databases."
    resp = Response('{"status": "success", "message": "", "payload": ' + dmcdb.get_data_json_single('''SELECT * FROM SourceDatabase;''') + '}')
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp

if __name__ == '__main__':
    app.run(debug=True)