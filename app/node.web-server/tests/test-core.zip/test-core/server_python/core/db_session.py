#!/usr/bin/python

import MySQLdb
import cx_Oracle
import utilities
import logging

"""
 * @author n662293
 """

logging.basicConfig(level=logging.INFO)

"""
 * Function to establish database connection
 """
def db_session(data_source, db_schema, host_name, user_name, password, run_type):
    utilities.print_info("Connecting to " + data_source.upper() + " datasource...")

    conn = ''
    message = ''
    db = db_schema
    host = host_name
    usr = user_name
    pwd = password

    # ------------------------ Make Connection ------------------------
    if str(data_source).upper() == "MYSQL":
        try:
            conn = MySQLdb.connect(host, usr, pwd, db)
            utilities.print_info("Connection sucessfull...")
        except Exception as e:
            if str(run_type).upper() == 'S':
                utilities.abort_with_traceback_msg("db_session.py: The Exception during db.connect: " + str(e))
            else:
                if e.args.__len__() == 2:
                    message = str(e.args[1])
                else:
                    message = str(e).replace('"','')

    elif str(data_source).upper() == "ORACLE":
        try:
            conn = cx_Oracle.connect(usr, pwd, host)
            utilities.print_info("Connection sucessfull...")
        except Exception as e:
            if str(run_type).upper() == 'S':
                utilities.abort_with_traceback_msg("db_session.py: The Exception during db.connect: " + str(e))
            else:
                if e.args.__len__() == 2:
                    message = str(e.args[1])
                else:
                    message = str(e).replace('"','')

    return conn, message