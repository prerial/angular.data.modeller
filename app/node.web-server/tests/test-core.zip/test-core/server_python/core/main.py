 #!/usr/bin/python

# -run s -d mysql -s northwind -a Employees,Customers,Orders -tdb hive -tdbschema have_dbschema -ttbltype managed -ttblformat text -tschema Flatten -erwinf C:\FAST\development\git\dmo-core-services\server_python\data\input\NorthwindXmlMinFile.xml
# -run s -d mysql -s northwind -a Employees,Customers,Orders -tdb hive -tdbschema have_dbschema -ttbltype managed -ttblformat text -tschema Flatten

import argparse
import csv
import json
import logging
import utilities

from anchor_tables import select_anchor_tables
from db_metadata import get_metadata
from db_session import db_session
from generate_entity_json import generate_json
from generate_session_json import generate_session_param_json
from generate_session_json import extract_session_param_json
from relationships import generate_relationships
from patterns import validate_tables_selection
from generate_tree import generate_relationships_tree
from generate_erd import generate_erdjson
from denormalization import generate_denorm_ddl
from generate_dictionary import generate_dict
from erwin_xmlparser import erwin_xml_parser
from helpers import check_args
from log import start_logging
from url_parser import parse_url
from version import version as __version__

"""
 * @author n662293
 """

"""
 * Entry point for the Data Model Optimizer application
 """
def main(url):

    parser = argparse.ArgumentParser(prog='dmo')

    parser.add_argument('-run', nargs='?', help='Name of the run type.')
    parser.add_argument('-d', nargs='?', help='Name of the source database.')
    parser.add_argument('-s', nargs='?', help='Name of the schema.')
    parser.add_argument('-host', nargs='?', help='Name of the host.')
    parser.add_argument('-usr', nargs='?', help='Name of the user.')
    parser.add_argument('-pwd', nargs='?', help='Password.')
    parser.add_argument('-erwinf', nargs='?', help='Name of the erwin xml file.')
    parser.add_argument('-r', nargs='?', help='Name of the relationships csv file.')
    parser.add_argument('-a', nargs='?', help='Name of the anchor tables list.')
    parser.add_argument('-i', nargs='?', help='Name of the include tables list.')
    parser.add_argument('-x', nargs='?', help='Name of the exclude tables list.')
    parser.add_argument('-tdb', nargs='?', help='Name of the target database.')
    parser.add_argument('-tdbschema', nargs='?', help='Name of the target database schema.')
    parser.add_argument('-ttbltype', nargs='?', help='Name of the table type.')
    parser.add_argument('-ttblformat', nargs='?', help='Name of the table format.')
    parser.add_argument('-ttbllocation', nargs='?', help='Name of the external tables parent directory location.')
    parser.add_argument('-tschema', nargs='?', help='Name of the target schema.')
    parser.add_argument('-nof', nargs='?', help='Name of the native output file.')
    parser.add_argument('-hof', nargs='?', help='Name of the hive output file.')
    parser.add_argument('-dmlf', nargs='?', help='Name of the dml output file.')
    parser.add_argument('-v', help='Prints version number.',action='store_true')

    args = parser.parse_args()
    denorm_type = "None"
    exception_flag = 0

    logger = logging.getLogger()

    if str(url) != 'None' and str(url) != "":
        args, denorm_type, exception_flag, message = parse_url(url, args)

    if exception_flag == 1:
        result_json = generate_error_json_response(message)
    else:
        check_args(args)

        if args.v:
            print('Data Model Optimizer version {}.'.format(__version__))
            exit(0)

        try:
            """
             * run paramter is
             * S indicates Standalone run
             * denorm_type indicates GUI run
             """
            if str(args.run).upper() == 'S':
                result_json = denormalize(args.run, args.d, args.s, args.host, args.usr, args.pwd, args.erwinf, args.r,
                                          args.a, args.i, args.x, args.tdb, args.tdbschema, args.ttbltype, args.ttblformat,
                                          args.ttbllocation, args.tschema, args.nof, args.hof, args.dmlf,
                                          denorm_type)

            elif denorm_type.upper() == 'TRUE' :
                result_json = denormalize(args.run, args.d, args.s, args.host, args.usr, args.pwd, args.erwinf, args.r,
                                          args.a, args.i, args.x, args.tdb, args.tdbschema, args.ttbltype, args.ttblformat,
                                          args.ttbllocation, args.tschema, args.nof, args.hof, args.dmlf,
                                          denorm_type)

            elif denorm_type.upper() == "FALSE" or denorm_type.upper() == "NONE":
                result_json = denormalize(args.run, args.d, args.s, args.host, args.usr, args.pwd, args.erwinf, args.r,
                                          args.a, args.i, args.x, args.tdb, args.tdbschema, args.ttbltype, args.ttblformat,
                                          args.ttbllocation, args.tschema, args.nof, args.hof, args.dmlf,
                                          denorm_type)

        except Exception as e:
            utilities.abort_with_traceback_msg("Fatal Error: " + str(e))
            if str(args.run).upper() != 'S':
                result_json = generate_error_json_response(str(e))

    return result_json
"""
 * Function to denormalizes the tables from relational databases or erwin xml file
 @data_source: dattabase name
 @db_schema: schema name
 @anchor_tables: list of anchor tables
 @erwin_xmlfile: erwin xml file
 @exclude_tables: list of tables excluded from denormalizattion process
 @include_tables: list of tables included for denormalization process
 @relationships_file: if relationships are not existing between tables, then provide through this file
 @native_outputfile: native denormalized ddl output file
 @hive_outputfile: hive denormalized ddl output file
 @dml_outputfile: denormalized dml file which contains insert statements to insert data from base tables to denormalized tables
 """

def denormalize(run_type, data_source, db_schema, host_name, user_name, password, erwin_xmlfile, relationships_file,
                anchor_tables, include_tables, exclude_tables, t_db, t_dbschema, t_tbltype, t_tblformat,
                t_tbllocation, target_schema, native_outputfile, hive_outputfile, dml_outputfile, denorm_type):

    result_json = []

    start_logging(data_source, erwin_xmlfile)

    # To run standalone mode
    if str(run_type).upper() == 'S':

        if str(erwin_xmlfile) == "None":
            conn, message = db_session(data_source, db_schema, host_name, user_name, password, run_type)
            metadata = get_metadata(conn, data_source, db_schema)
            relationships_data = generate_relationships(relationships_file, metadata, exclude_tables, include_tables)
            generate_csv(metadata, relationships_data)
            entity_json, table_list = generate_json(data_source, metadata, relationships_data)
            relationships_tree, root_nodes = generate_relationships_tree(entity_json)
            session_param_dict = generate_session_param_json(table_list, root_nodes, data_source, db_schema, host_name, user_name,
                                                             password, t_db, t_dbschema, t_tbltype, t_tblformat,
                                                             t_tbllocation, target_schema)

            erd_json = generate_erdjson(entity_json, relationships_tree, db_schema, session_param_dict)
            exception_flag, message, an_table_list, ex_table_list, in_table_list = validate_tables_selection(session_param_dict, anchor_tables, exclude_tables, include_tables, denorm_type)
            if exception_flag == 1:
                utilities.abort_with_traceback_msg(message)
            else:
                node_dict, node_columns_dict, ddl_dict = generate_dict(entity_json, ex_table_list, in_table_list, session_param_dict)
                anchors_dcit = select_anchor_tables(node_dict, an_table_list, in_table_list)
                denorm_json = generate_denorm_ddl(ddl_dict, anchors_dcit, session_param_dict, native_outputfile, hive_outputfile, dml_outputfile)
                result_json = denorm_json
        else:
            data_source = "ERWIN"
            entity_json, table_list, db_schema = erwin_xml_parser(erwin_xmlfile)
            relationships_tree, root_nodes = generate_relationships_tree(entity_json)
            session_param_dict = generate_session_param_json(table_list, root_nodes, data_source, db_schema, host_name,
                                                             user_name, password, t_db, t_dbschema, t_tbltype, t_tblformat,
                                                             t_tbllocation, target_schema)
            erd_json = generate_erdjson(entity_json, relationships_tree, db_schema, session_param_dict)
            exception_flag, message, an_table_list, ex_table_list, in_table_list = validate_tables_selection(session_param_dict, anchor_tables, exclude_tables, include_tables, denorm_type)
            if exception_flag == 1:
                utilities.abort_with_traceback_msg(message)
            else:
                node_dict, node_columns_dict, ddl_dict = generate_dict(entity_json, ex_table_list, in_table_list, session_param_dict)
                anchors_dcit = select_anchor_tables(node_dict, an_table_list, in_table_list)
                denorm_json = generate_denorm_ddl(ddl_dict, anchors_dcit, session_param_dict, native_outputfile, hive_outputfile, dml_outputfile)
                result_json = denorm_json

    # UI Single step process
    elif denorm_type.upper() == 'TRUE':
        conn, message = db_session(data_source, db_schema, host_name, user_name, password, run_type)
        if conn == '':
            result_json = generate_error_json_response(message)
        else:
            metadata = get_metadata(conn, data_source, db_schema)
            relationships_data = generate_relationships(relationships_file, metadata, exclude_tables, include_tables)
            generate_csv(metadata, relationships_data)
            entity_json, table_list = generate_json(data_source, metadata, relationships_data)
            relationships_tree, root_nodes = generate_relationships_tree(entity_json)
            session_param_dict = generate_session_param_json(table_list, root_nodes, data_source, db_schema, host_name,
                                                             user_name, password, t_db, t_dbschema, t_tbltype, t_tblformat,
                                                             t_tbllocation, target_schema)

            erd_json = generate_erdjson(entity_json, relationships_tree, db_schema, session_param_dict)

            exception_flag, message, an_table_list, ex_table_list, in_table_list = validate_tables_selection(session_param_dict, anchor_tables, exclude_tables, include_tables, denorm_type)
            if exception_flag == 1:
                result_json = generate_error_json_response(message)
            else:
                node_dict, node_columns_dict, ddl_dict = generate_dict(entity_json, ex_table_list, in_table_list, session_param_dict)
                anchors_dcit = select_anchor_tables(node_dict, an_table_list, in_table_list)
                denorm_json = generate_denorm_ddl(ddl_dict, anchors_dcit, session_param_dict, native_outputfile, hive_outputfile, dml_outputfile)
                result_json = denorm_json

    # UI Two step process:
    # Request No2 : to render erd json schema for visulization.
    elif denorm_type.upper() == "FALSE":
        conn, message = db_session(data_source, db_schema, host_name, user_name, password, run_type)
        if conn == '':
            result_json = generate_error_json_response(message)
        else:
            metadata = get_metadata(conn, data_source, db_schema)
            relationships_data = generate_relationships(relationships_file, metadata, exclude_tables, include_tables)
            generate_csv(metadata, relationships_data)
            entity_json, table_list = generate_json(data_source, metadata, relationships_data)
            relationships_tree, root_nodes = generate_relationships_tree(entity_json)
            session_param_dict = generate_session_param_json(table_list, root_nodes, data_source, db_schema, host_name,
                                                             user_name, password, t_db, t_dbschema, t_tbltype, t_tblformat,
                                                             t_tbllocation, target_schema)
            erd_json = generate_erdjson(entity_json, relationships_tree, db_schema, session_param_dict)
            result_json = erd_json

    # Request No3 : To render denormalize json schema, ddl, dml.
    elif denorm_type.upper() == "NONE":
        conn, message = db_session(data_source, db_schema, host_name, user_name, password, run_type)
        if conn == '':
            result_json = generate_error_json_response(message)
        else:
            metadata = get_metadata(conn, data_source, db_schema)
            relationships_data = generate_relationships(relationships_file, metadata, exclude_tables, include_tables)
            entity_json, table_list = generate_json(data_source, metadata, relationships_data)
            session_param_dict = extract_session_param_json()
            exception_flag, message, an_table_list, ex_table_list, in_table_list = validate_tables_selection(session_param_dict, anchor_tables, exclude_tables, include_tables, denorm_type)
            if exception_flag == 1:
                result_json = generate_error_json_response(message)
            else:
                node_dict, node_columns_dict, ddl_dict = generate_dict(entity_json, ex_table_list, in_table_list, session_param_dict)
                anchors_dcit = select_anchor_tables(node_dict, an_table_list, in_table_list)
                denorm_json = generate_denorm_ddl(ddl_dict, anchors_dcit, session_param_dict, native_outputfile, hive_outputfile, dml_outputfile)
                result_json = denorm_json

    utilities.print_info("Denormalization process completed...")

    return result_json

"""
 * Function to save metadata into csv file for reference purpose
 """
def generate_csv(metadata, relationships_data):
    utilities.print_info("Generating csv file started...")

    csv_file = utilities.Config.METADATA_CSV_FILE
    csvfile = csv.writer(open(csv_file, 'wb'))

    # Writting metadata in csv file
    field_names = metadata[0]
    header = '|'.join(map(str, field_names))
    csvfile.writerow(header.split(("|")))

    for c in metadata[1]:
        c_tbl = c[1]
        row = "|".join(map(str, c))
        csvfile.writerow(row.split("|"))

    utilities.print_info("Generating csv file completed...")

"""
 * Function to generate error json response
 """
def generate_error_json_response(message):
    result_json_data = {
        "status": "error",
        "message": message,
        "payload": []
    }
    result_json = json.dumps(result_json_data, indent=1)
    return result_json

if __name__ == '__main__':
    main(url = '')