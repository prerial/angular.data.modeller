#!/usr/bin/python

import urlparse
from generate_session_json import extract_session_param_json

"""
 * @author n662293
 """

"""
 * Function to parse UI URL
 """
def parse_url(url, args):

    denorm_type = "None"
    exception_flag = 0
    message = ""
    source_db = ""

    url_dict = urlparse.parse_qs(urlparse.urlparse(url).query)

    for k, v in url_dict.items():
        if k == 'schema_include':
            for i in v:
                datasource = str(i).split("_")
                source_db = datasource[0]
                args.s = datasource[1]
        elif k == 'conn_string':
            for i in v:
                args.host = i
        elif k == 'conn_username':
            for i in v:
                args.usr = i
        elif k == 'conn_password':
            for i in v:
                args.pwd = i
        elif k == 'schema_target':
            for i in v:
                args.tschema = i
        elif k == 'sdatabase':
            for i in v:
                args.d = i
        elif k == 'tdatabase':
            for i in v:
                args.tdb = i
        elif k == 'database_schema':
            for i in v:
                args.tdbschema = i
        elif k == 'location':
            for i in v:
                args.ttbllocation = i
        elif k == 'table_type':
            for i in v:
                args.ttbltype = i
        elif k == 'table_file_format':
            for i in v:
                args.ttblformat = i
        elif k == 'single':
            for i in v:
                denorm_type = i
        elif k == 'anchors':
            for i in v:
                args.a = i
        elif k == 'tables_include':
            for i in v:
                args.i = i
        elif k == 'tables_exclude':
            for i in v:
                args.x = i

    if denorm_type.upper() == "NONE":
        session_param_dict = extract_session_param_json()

        if session_param_dict.has_key("source_db"):
            args.d = session_param_dict.get("source_db")
            source_db = args.d

        if session_param_dict.has_key("source_schema"):
            args.s = session_param_dict.get("source_schema")

        if session_param_dict.has_key("target_db"):
            args.tdb = session_param_dict.get("target_db")

        if session_param_dict.has_key("target_db_schema"):
            args.tdbschema = session_param_dict.get("target_db_schema")

        if session_param_dict.has_key("target_tbl_type"):
            args.ttbltype = session_param_dict.get("target_tbl_type")

        if session_param_dict.has_key("target_tbl_format"):
            args.ttblformat = session_param_dict.get("target_tbl_format")

        if session_param_dict.has_key("target_tbl_location"):
            args.ttbllocation = session_param_dict.get("target_tbl_location")

        if session_param_dict.has_key("target_schema"):
            args.tschema = session_param_dict.get("target_schema")

    if str(args.tdb).lower() != "hive":
        exception_flag = 1
        message = "Currently denormalization supporting for Hive target database, please select Hive"

    if str(source_db).lower() != str(args.d).lower():
        exception_flag = 1
        message = "Selection of Data Source and Source Database options are wrong, please select correct combination"

    return args, denorm_type, exception_flag, message
