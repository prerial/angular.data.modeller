#!/usr/bin/python

import utilities
import operator
import csv

"""
 * @author n662293
 """

"""
 * Function to generate relationships tree
 """
def generate_relationships_tree(entity_json):
    utilities.print_info("Generating relationships tree started...")

    node_dict, node_weights, independent_root_nodes = generate_dict_for_tree(entity_json)

    root_nodes = generate_root_nodes_from_leafs(node_dict, node_weights, independent_root_nodes)

    relationship_tree = []

    rel_tree_file = utilities.Config.REL_TREE_FILE
    relfile = csv.writer(open(rel_tree_file, 'wb'))

    for key in root_nodes:
        if node_dict.has_key(key):
            anchors = list(node_dict.get(key))
            root = []
            root.append(key)
            current_level = 1
            start_node = key
            row = ":L" + str(current_level) + ":" + str(key)
            relationship_tree.append(row)

            if anchors != ['']:
                relationship_tree = generate_rel_tree(root, node_dict, node_weights, anchors, start_node, relationship_tree)

    for row in relationship_tree:
        relfile.writerow(row.split(","))

    utilities.print_info("Generating relationships tree completed...")

    return relationship_tree, root_nodes

"""
 * Function to generate dictionaries for tree
 """
def generate_dict_for_tree(entity_json):
    utilities.print_info("Generating dictionaries for relationships tree started...")

    node_list = []
    node_dict = {}
    node_weights = {}
    unique_nodes = []
    referenced_nodes = []

    for dict in entity_json:
        entity_flag = 0
        for k, v in dict.iteritems():
            flag = 0
            if dict.has_key(k):
                if str(k).lower() == "name":
                    table_name = dict.get(k)
                    entity_flag = 1

                if entity_flag == 1:
                    if str(k).lower() == "columns":
                        columns = dict.get(k)
                        for col_dict in columns:
                            constraint_type = col_dict.get("constraintType")
                            referenced_table_name = col_dict.get("referencedTableName")

                            if constraint_type == "FOREIGN KEY":
                                node_list.append((table_name, referenced_table_name))
                                node_list.append((referenced_table_name, table_name))
                                if table_name not in referenced_nodes:
                                    referenced_nodes.append(table_name)
                                if referenced_table_name not in referenced_nodes:
                                    referenced_nodes.append(referenced_table_name)
                                flag = 1

        if flag == 0:
            unique_nodes.append(table_name)

        independent_root_nodes = [item for item in unique_nodes if item not in referenced_nodes]

    for node in independent_root_nodes:
        node_list.append((node, ""))

    for x in node_list:
        node_dict.setdefault(x[0], set([])).add(x[1])

    for k, v in node_dict.iteritems():
        count = 0
        for x in node_dict.get(k):
            if x != "":
                count += 1
        node_weights[k] = count

    utilities.print_info("Generating dictionaries for relationships tree completed...")
    return node_dict, node_weights, independent_root_nodes

"""
 * Function to generate root nodes for all leaf nodes
 """
def generate_root_nodes_from_leafs(node_dict, node_weights, independent_root_nodes):
    utilities.print_info("Generating root nodes for all leaf nodes started...")

    leaf_nodes = []
    root_nodes = []

    if not node_weights == {}:
        node_weights_sorted = sorted(node_weights.iteritems(), key=operator.itemgetter(1), reverse=True)
        root = node_weights_sorted[0]
        key = root[0]
        root_nodes.append(key)

    for n, v in node_weights.iteritems():
        if v == 1:
            leaf_nodes.append(n)

    for key in leaf_nodes:
        anchors = []
        if node_dict.has_key(key):
            anchors.append(key)
            for keys in anchors:
                init = 0
                visited_tbls = leaf_to_root_traversal(node_dict, node_dict[keys], init, anchors)
                root = ""
                weight = 0
                for n in visited_tbls:
                    if node_weights.has_key(n):
                        if weight < node_weights.get(n):
                            root = n
                            weight = node_weights.get(n)

                if root not in root_nodes:
                    root_nodes.append(root)

    for node in independent_root_nodes:
        root_nodes.append(node)

    utilities.print_info("Generating root nodes for all leaf nodes completed...")
    return root_nodes

"""
 * Function to traversal from leaf node to root node
 """
def leaf_to_root_traversal(graph, node, init, anchors, visited =[]):
    if init == 0:
        visited[:] =[]
    for n in node:
        if n in graph.keys():
            if n not in visited and n not in anchors:
                visited.append(n)
                init = 1
                leaf_to_root_traversal(graph, graph[n], init, anchors, visited)
        elif n not in anchors:
            visited.append(n)
    return visited

"""
 * Function to generate relationship tree
 """
def generate_rel_tree(root, node_dict, node_weights, anchors, start_node, relationship_tree):

    parent_level = 1
    current_level = 2
    prev_child = 0
    cur_child = 0
    prev_parent = start_node

    for keys in anchors:
        root.append(keys)
        cur_parent = keys
        cur_child += 1
        child = 1

        row = "L" + str(parent_level) + ":L" + str(current_level) + "C" + str(cur_child) + ":" + str(keys)
        relationship_tree.append(row)

        if keys in node_weights:
            prev_weight = node_weights.get(keys)

        relationship_tree = generate_tree(root, node_dict, node_weights, prev_parent, cur_parent, prev_weight, parent_level, current_level, prev_child, cur_child, child, node_dict[keys], anchors, relationship_tree)

    return relationship_tree

"""
 * Function to implement algorithm for generating tree
 """
def generate_tree(root, graph, node_weights, prev_parent, cur_parent, prev_weight, parent_level, current_level, prev_child, cur_child, child, node, anchors, relationship_tree):

    for n in node:
        if n in graph.keys():
            if n not in root and n not in anchors:

                root.append(n)
                prev_parent = cur_parent
                prev_child = cur_child

                if n in node_weights:
                    weight = node_weights.get(n)

                    parent_level += 1
                    current_level += 1

                    if weight > 1:
                        cur_parent = n
                        child = 1

                    if prev_parent == cur_parent:
                        if prev_weight == 1 and weight == 1:
                            parent_level -= 1
                            current_level -= 1
                            child += 1
                    else:
                        child = 1
                        cur_child = child

                    prev_weight = weight

                row = "L" + str(parent_level) + "C" + str(prev_child) + ":L" + str(current_level) + "C" + str(child) + ":" + str(n)

                relationship_tree.append(row)

                generate_tree(root, graph, node_weights, prev_parent, cur_parent, prev_weight, parent_level, current_level, prev_child, cur_child, child, graph[n], anchors, relationship_tree)

    return relationship_tree