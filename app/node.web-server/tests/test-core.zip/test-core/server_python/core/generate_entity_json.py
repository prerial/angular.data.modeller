#!/usr/bin/python

import utilities
import json
import re
"""
 * @author n662293
 """

"""
 * Function to generate entity json from metadata
 """
def generate_json(data_source, metadata, relationships_data):
    utilities.print_info("Generating entity json started...")

    json_file = utilities.Config.JSON_FILE
    jsonfile = open(json_file, "wb")

    # Generating json from metadata
    table_schema = metadata[1][0][0]
    table_name_tmp = metadata[1][0][1]

    entity_json = []

    entity_data = {
        "name": table_name_tmp,
        "namespace": table_schema + "." + table_name_tmp,
        "columns" : []
    }

    table_list = []

    for c in metadata[1]:
        c_tbl = c[1]

        table_schema = c[0]
        table_name = c[1]
        column_name = c[2]
        column_type = c[4]
        data_length = c[5]
        numeric_precision = c[9]
        numeric_scale = c[10]
        referenced_table_name = "No"
        if str(c[14]) != "None":
            referenced_table_name = c[14]
        referenced_column_name = "No"
        if str(c[15]) != "None":
            referenced_column_name = c[15]
        constraint_type = "No"
        if str(c[17]) != "None":
            constraint_type = c[17]

        if str(data_source).upper() == "MYSQL":
            expr = re.compile("(\w+(?: \([^\)]*\))?)")
            field_dtype_list = expr.findall(column_type)
            field_datatype = field_dtype_list[0]

            data_length = 0

            if len(field_dtype_list) == 2:
                data_length = field_dtype_list[1]
            if len(field_dtype_list) == 3:
                data_length = field_dtype_list[1] + "," + field_dtype_list[2]

        elif str(data_source).upper() == "ORACLE":
            field_datatype = column_type
            if column_type == "number" or column_type == "number_int" or \
               column_type == "decimal" or column_type == "double":
                if str(numeric_precision) != "None":
                    data_length = str(numeric_precision) + "," + str(numeric_scale)

        p_key = "false"
        if str(constraint_type).upper() == "PRIMARY KEY":
            p_key = "true"

        if table_name_tmp == table_name :
            entity_data["columns"].append(
                {"name": column_name, "type": field_datatype, "size": data_length, "primaryKey": p_key, \
                 "constraintType": constraint_type, "referencedTableName": referenced_table_name,
                 "referencedColumnName": referenced_column_name})
        else:
            if not entity_data["columns"] == []:
                entity_json.append(entity_data)
                table_list.append(entity_data.get("name"))

            entity_data = ""
            entity_data = {
                "name": table_name,
                "namespace": table_schema + "." + table_name,
                "columns": []
            }

            entity_data["columns"].append(
                {"name": column_name, "type": field_datatype, "size": data_length,
                 "primaryKey": p_key, \
                 "constraintType": constraint_type, "referencedTableName": referenced_table_name,
                 "referencedColumnName": referenced_column_name})

        table_name_tmp = table_name

    # Handling last entity
    if not entity_data["columns"] == []:
        entity_json.append(entity_data)
        table_list.append(entity_data.get("name"))

    json.dump(entity_json, jsonfile, indent=1)

    utilities.print_info("Generating entity json completed...")

    return entity_json, table_list