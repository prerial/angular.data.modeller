#!/usr/bin/python

import utilities
import json
from flask import session

"""
 * @author n662293
 """

"""
 * Function to generate session parameters json
 """
def generate_session_param_json(table_list, root_nodes, data_source, db_schema, host_name, user_name,
                                password, t_db, t_dbschema, t_tbltype, t_tblformat,
                                t_tbllocation, target_schema):
    utilities.print_info("Generating session parameters json started...")

    session_param_json_file = utilities.Config.SESSION_PARAM_JSON_FILE
    sessionparamjsonfile = open(session_param_json_file, "wb")

    session_param_json = {
        "source_db": data_source,
        "host_name": host_name,
        "user_name": user_name,
        "password": password,
        "source_schema": db_schema,
        "tables": [],
        "root_nodes": [],
        "target_db": t_db,
        "target_db_schema": t_dbschema,
        "target_tbl_type": t_tbltype,
        "target_tbl_format": t_tblformat,
        "target_tbl_location": t_tbllocation,
        "target_schema": target_schema
    }
    session_param_json["tables"] = table_list
    session_param_json["root_nodes"] = root_nodes

    json.dump(session_param_json, sessionparamjsonfile, indent=1)

    utilities.print_info("Generating session parameters json completed...")

    return session_param_json

"""
 * Function to extract session parameters json
 """
def extract_session_param_json():

    session_param_json = {}

    session_param_json_file = utilities.Config.SESSION_PARAM_JSON_FILE

    with open(session_param_json_file) as sessionparamjsonfile:
        session_param_json = json.load(sessionparamjsonfile)

    if 'session_param_json' in session:
        print "session variables"
        print session['session_param_dict']
        session_param_json = session['session_param_json']

    return session_param_json