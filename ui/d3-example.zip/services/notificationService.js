(function() {
    "use strict";

    angular.module('dmc.utils').provider('notificationService', [ function() {

            var settings = {
                    styling: 'bootstrap3'
                },
                stacks = {},
                defaultStack = false;

            function getConfig(stackName) {
                var config = angular.copy(settings);
                if ((stackName || (stackName = defaultStack)) && stackName in stacks) {
                    config.stack = stacks[stackName].stack;
                    if (stacks[stackName].addclass) {
                        config.addclass = 'addclass' in config? config.addclass + ' ' + stacks[stackName].addclass
                            : stacks[stackName].addclass;
                    }
                }
                return config;
            }

            this.setDefaults = function(defaults) {
                settings = defaults;
                return this;
            };

            this.setStack = function(name, addclass, stack) {
                if (angular.isObject(addclass)) {
                    stack = addclass;
                    addclass = false;
                }
                stacks[name] = {
                    stack: stack,
                    addclass: addclass
                };
                return this;
            };

            this.setDefaultStack = function(name) {
                defaultStack = name;
                return this;
            };

            this.$get = [ function() {
                return {
                     getSettings: function() {
                        return settings;
                    },
                    notice: function(content, stack) {
                        var config = getConfig(stack);
                        config.type = 'notice';
                        config.text = content;
                        return this.notify(config);
                    },
                    info: function(content, stack) {
                        var config = getConfig(stack);
                        config.type = 'info';
                        config.text = content;
                        return this.notify(config);
                    },
                    success: function(content, stack) {
                        var config = getConfig(stack);
                        config.type = 'success';
                        config.text = content;
                        return this.notify(config);
                    },
                    error: function(content, stack) {
                        var config = getConfig(stack);
                        config.type = 'error';
                        config.text = content;
                        return this.notify(config);
                    },
                    notifyWithDefaults: function(options, stack) {
                        var defaults = getConfig(stack);
                        var combined = angular.extend(defaults, options);
                        return this.notify(combined);
                    },
                    notify: function(config) {
                        return new PNotify(config);
                    },
                    removeNotifications: function() {
                        return PNotify.removeAll();
                    }
                };
            }];
        }]);
    })();
