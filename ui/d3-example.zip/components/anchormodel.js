(function() {
    "use strict";

    angular.module('app.dmc').component('anchormodel', {
        templateUrl: 'views/anchorModelView.html',
        controller: 'AnchorModelController'
    });

    angular.module('app.dmc').controller('AnchorModelController', ['$scope', '$location', 'Messaging', 'notificationService', 'UtilsService', 'messageService', 'CommonRequestService',
        function($scope, $location, messaging, notification, utilsService, messageService, commonRequestService) {

            var self = this;
            this.denormTables = [];
            function buildString(dt, type){
                var str = '';
                dt.forEach(function(mem){
                    str = str + '\n\n' + mem[type];
                });
                return str;
            }
            utilsService.showSpinner();
            var formdata = messageService.getMessage();
            if(!formdata){
                utilsService.hideSpinner();
                $location.path('/login');
                return;
            }
            var data = {'requestType': 'getErdAnchorData', 'data': formdata.data};
            commonRequestService.getRequestData(data)
                .then(function(resp){
                    if(resp.data.status === 'success'){
                        var respdata = resp.data.payload;
                        self.denormTables = respdata;
                        var type = 'text/plain;charset=utf-8';
                        var ddlname = 'ddlfile.txt';
                        var ddltext = buildString(respdata, 'ddl');
                        var dlbtn = $("#dlbtn")[0];
                        var ddlfile = new Blob([ddltext], {type: type});
                        dlbtn.href = URL.createObjectURL(ddlfile);
                        dlbtn.download = ddlname;

                        var dmlname = 'dmlfile.txt';
                        var dmltext = buildString(respdata, 'dml');
                        var dmbtn = $("#dmbtn")[0];
                        var dmlfile = new Blob([dmltext], {type: type});
                        dmbtn.href = URL.createObjectURL(dmlfile);
                        dmbtn.download = dmlname;

                        utilsService.hideSpinner();
                    }else{
                        notification.notify(utilsService.setErrorNotification(messaging.error.appTitle, resp.data.message));
                        utilsService.hideSpinner();
                    }
                }).catch( function(){
                    notification.notify(utilsService.setErrorNotification(messaging.error.serverTitle, messaging.error.serverErrorMsg ));
                    utilsService.hideSpinner();
            });

            this.cancel = function(){
                if(formdata.data.indexOf('single') !== -1){
                    $location.path('/source');
                }else{
                    $location.path('/datamodel');
                }
            }

        }]);
})();
