/**
 * Created by U160964 on 11/1/2017.
 */
(function() {
    "use strict";

    angular.module('app.dmc').component('connections', {
        templateUrl: 'views/connectionsView.html',
        controller: 'ConnectionController'
    });

    angular.module('app.dmc').controller('ConnectionController', ['$scope', '$location', 'Messaging', 'notificationService', 'UtilsService', 'CommonRequestService',
        function($scope, $location, messaging, notification, utilsService, commonRequestService) {

            var self = this;
            self.selectedConn = null;
            self.databases = {};
            self.connection = {};
            var data = {'requestType': 'getDatabases'};
            commonRequestService.getRequestData(data)
                .then(function(resp){
                    if(resp.data.status === 'success') {
                        self.databases = resp.data.payload;
                        utilsService.hideSpinner();
                    }else{
                        notification.notify(utilsService.setErrorNotification(messaging.error.appTitle, resp.data.message));
                        utilsService.hideSpinner();
                    }
                }).catch( function(){
                    notification.notify(utilsService.setErrorNotification(messaging.error.serverTitle, messaging.error.serverErrorMsg ));
                    utilsService.hideSpinner();
            });

            function getConnections() {
                utilsService.showSpinner();
                data = {'requestType': 'getConnectionsData'};
                commonRequestService.getRequestData(data)
                    .then(function (resp) {
                        if (resp.data.status === 'success') {
                            self.connections = resp.data.payload;
                            utilsService.hideSpinner();
                        } else {
                            notification.notify(utilsService.setErrorNotification(messaging.error.appTitle, resp.data.message));
                            utilsService.hideSpinner();
                        }
                    }).catch(function () {
                        notification.notify(utilsService.setErrorNotification(messaging.error.serverTitle, messaging.error.serverErrorMsg ));
                        utilsService.hideSpinner();
                    });
            }
            getConnections();

            self.onSelect = function onSelect(conn) {
                self.selectedConn = conn;
            };

            self.delete = function deleteConnection(conn){
                utilsService.showSpinner();
                var reqParam = {'requestType': 'deleteConnection', 'data':conn.ID};
                commonRequestService.postRequestData(reqParam)
                    .then(function (resp) {
                        if (resp.data.status === 'success') {
                            getConnections();
                            $('#connectionModal').modal('hide');
                            notification.success(resp.data.message);
                        } else {
                            notification.notify(utilsService.setErrorNotification(messaging.error.appTitle, resp.data.message));
                            utilsService.hideSpinner();
                        }
                    }).catch(function () {
                        notification.notify(utilsService.setErrorNotification(messaging.error.serverTitle, messaging.error.serverErrorMsg ));
                        utilsService.hideSpinner();
                    });
            };
            self.gotoDetail = function gotoDetail(conn){
                self.connection = conn;
            };
            self.formSubmit = function(conn) {
                conn.type = !conn.ID? 'save':'update';
                var reqParam = {'requestType': 'saveConnection', 'data':conn};
                commonRequestService.postRequestData(reqParam)
                    .then(function (resp) {
                        if (resp.data.status === 'success') {
                            getConnections();
                            $('#connectionModal').modal('hide');
                            notification.success(resp.data.message);
                        } else {
                            notification.notify(utilsService.setErrorNotification(messaging.error.appTitle, resp.data.message));
                            utilsService.hideSpinner();
                        }
                    }).catch(function () {
                        notification.notify(utilsService.setErrorNotification(messaging.error.serverTitle, messaging.error.serverErrorMsg ));
                        utilsService.hideSpinner();
                });
            }

        }]);
})();

