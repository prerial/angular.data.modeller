(function() {
    "use strict";

    angular.module('app.dmc').component('sourceSchema', {
        templateUrl: 'views/sourceSchemaView.html',
        controller: 'SourceSchemaController'

    });
    angular.module('app.dmc').controller('SourceSchemaController', ['$scope', '$location', 'Messaging', 'notificationService', 'UtilsService', 'messageService', 'CommonRequestService',
        function($scope, $location, messaging, notification, utilsService, messageService, commonRequestService) {

            var self = this;
            self.datasource = {};
            self.connections = {};
            self.single = false;

            utilsService.showSpinner();

            function isInputValid(formdata) {
                switch(formdata.schema_include){
                    case 'mysql_northwind':
                        if(formdata.sdatabase !== 'MySQL'){
                            notification.notify(utilsService.setErrorNotification(messaging.error.validation.input.inputTitle, messaging.error.validation.input.MySQL));
                            return false;
                        }
                        break;
                    case 'teradata_icdw':
                        if(formdata.sdatabase !== 'Teradata'){
                            notification.notify(utilsService.setErrorNotification(messaging.error.validation.input.inputTitle, messaging.error.validation.input.Teradata));
                            return false;
                        }
                        break;
                }
                return true;
            }

            this.submitForm = function(formdata){
                if(isInputValid(formdata)){
                    formdata.single = formdata.single||false;
                    var connection = formdata.schema_include;
                    formdata.conn_username = self.connections[connection].conn_username;
                    formdata.conn_password = self.connections[connection].conn_password;
                    formdata.conn_string = self.connections[connection].conn_string;
                    if(formdata.single){
                        var temp = [];
                        for (var key in formdata){
                            if (formdata.hasOwnProperty(key)) {
                                console.log(key + '=' + formdata[key]);
                                temp.push(key + '=' + formdata[key]);
                            }
                        }
                        var str = temp.join('&');
                        messageService.addMessage(str);
                        $location.path('/anchormodel');
                    }else{
                        messageService.addSource(formdata);
                        $location.path('/datamodel');
                    }
                }
            };

            var data = {'requestType': 'getDataSource'};
            commonRequestService.getRequestData(data)
                .then(function(resp){
                    if(resp.data.status === 'success') {
                        self.datasource = resp.data.payload;
                        self.datasource.dataSource.forEach(function(conn){
                            self.connections[conn.conn_name] = conn;
                            utilsService.hideSpinner();
                        });
                    }else{
                        notification.notify(utilsService.setErrorNotification(messaging.error.appTitle, resp.data.message));
                        utilsService.hideSpinner();
                    }
                }).catch( function(){
                    notification.notify(utilsService.setErrorNotification(messaging.error.serverTitle, messaging.error.serverErrorMsg ));
                    utilsService.hideSpinner();
                });

        }]);
})();
